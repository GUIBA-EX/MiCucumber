"""Verify independent scanner outputs and export bilingual results."""
from pathlib import Path
import sys,json,csv,collections,html,hashlib,shutil
src,run,out=map(Path,sys.argv[1:4]);out.mkdir(parents=True,exist_ok=True)
def read(p,sep=','):return list(csv.DictReader(p.open(),delimiter=sep))
def write(n,rr):
 with (out/n).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
meta={r['accession']:r for r in read(src/'metadata.tsv','\t')};tax={r['accession']:r for r in read(src/'target_taxonomy.tsv','\t')}
tab=collections.defaultdict(dict);hits=collections.defaultdict(dict)
for r in read(src/'target_detail.tsv','\t'):tab[r['name'],r['panel']][r['accession']]=r
for r in read(run/'independent_hits.tsv','\t'):hits[r['name'],r['role'],r['model']][r['accession']]=r
schemes=json.loads((run/'schemes.json').read_text());pairs={r['name']:r for r in json.loads((run/'selected_pairs.json').read_text())};pred=json.loads((run/'predictions.json').read_text())
checks=0
for n,pr in pred.items():
 for m,k in [('le2last3','coverage'),('exact','exact')]:
  actual={a for a,r in hits[n,'target','WC'].items() if r[m]=='1'}
  assert actual==set(pr[k]),(n,m,actual^set(pr[k]));checks+=len(tax)
original=json.loads((src/'baselines.json').read_text())[0]
assert pairs['MiCucumber_v4']['F']==original['F'] and pairs['MiCucumber_v4']['R']==original['R']
comparison=[];seq=[];miss=[];bg=[]
for s in schemes:
 for i,n in enumerate(s['pair_names'],1):
  p=pairs[n]
  assert s['locus']=='original-v4' or set(p['F']+p['R'])<=set('ACGT')
  seq.append(dict(scheme=s['name'],version=s['locus'],pairs=s['count'],reaction=i,pair_id=n,F=p['F'],R=p['R'],parent_ids=p.get('parent_ids','original unchanged')))
 risks={}
 for mod,metric in [('WC','le3'),('WC','le4'),('GT','le2')]:
  accessions={k for n in s['pair_names'] for k,r in hits[n,'background',mod].items() if r[metric]=='1'}
  risks[mod+'_'+metric]=len(accessions)
  for k in sorted(accessions):bg.append(dict(scheme=s['name'],model=mod,criterion=metric,accession=k,organism=meta[k]['organism'],clade=meta[k]['clade']))
 if s['locus']!='original-v4':assert risks['WC_le3']<=5 and risks['GT_le2']<=5
 for pn in ('common','own_region'):
  panel=tab[s['parent_panel_pair'],pn];groups=collections.defaultdict(list);cov=ex=nc=ne=den=0
  for k,r in panel.items():
   c=any(hits[n,'target','WC'].get(k,{}).get('le2last3')=='1' for n in s['pair_names']);e=any(hits[n,'target','WC'].get(k,{}).get('exact')=='1' for n in s['pair_names']);w=float(r['weight']);non=tax[k]['order']!='Apodida'
   cov+=w*c;ex+=w*e;nc+=w*c*non;ne+=w*e*non;den+=w*non
   groups[r['organism']].append((k,c,e))
   if s['locus']=='original-v4':
    assert c==(r['le2last3']=='True') and e==(r['exact']=='True');checks+=2
  comparison.append(dict(scheme=s['name'],locus=s['locus'],count=s['count'],panel=pn,n_labels=len(groups),n_haplotypes=len(panel),coverage_pct=cov*100,exact_pct=ex*100,non_Apodida_coverage_pct=nc/den*100,non_Apodida_exact_pct=ne/den*100,**risks))
  for label,rr in groups.items():
   if not all(r[1] for r in rr):miss.append(dict(scheme=s['name'],panel=pn,organism=label,order=tax[rr[0][0]]['order'],haplotypes=len(rr),detected=sum(r[1] for r in rr),exact=sum(r[2] for r in rr),status='fully_missed' if not any(r[1] for r in rr) else 'partially_missed'))
write('comparison.csv',comparison);write('primer_pairs.csv',seq);write('missed_taxa.csv',miss);write('offtargets.csv',bg)
with (out/'primers.fasta').open('w') as f:
 for r in seq:
  for d in ('F','R'):f.write(f">{r['scheme']}|PCR{r['reaction']}|{d}|{r['pair_id']}\n{r[d]}\n")
with (out/'v4_original.fasta').open('w') as f:
 for d in ('F','R'):f.write(f">MiCucumber_v4_original_{d}\n{original[d]}\n")
for n in ('candidate_scores.csv','selection_audit.csv','thermodynamics.csv','schemes.json','selected_pairs.json'):shutil.copy2(run/n,out/n)
validation=dict(status='PASS',target_boolean_checks=checks,concrete_candidate_count=len(read(run/'candidate_scores.csv')),nondegenerate_portfolios=8,original_v4_unchanged=True,unique_nondegenerate_pairs=len(pred),method='Python vectorized primer-hit pairing checked against independent exhaustive C++ both-strand full-sequence scan; all selected target coverage/exact accession sets agree.',scope='Separate PCR unions only. Same reference data used for design and evaluation; no wet-lab validation. Global optimality not claimed.',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in src.iterdir() if p.is_file()})
(out/'validation.json').write_text(json.dumps(validation,indent=2))
old={ (r['locus'],int(r['count'])):r for r in read(src/'compact_comparison.csv') if r['panel']=='common'}
deltas=[]
for r in comparison:
 if r['panel']!='common' or r['locus']=='original-v4':continue
 o=old[r['locus'],r['count']]
 deltas.append(dict(scheme=r['scheme'],degenerate_coverage=float(o['non_Apodida_coverage_pct']),nondegenerate_coverage=r['non_Apodida_coverage_pct'],coverage_change_pp=r['non_Apodida_coverage_pct']-float(o['non_Apodida_coverage_pct']),degenerate_exact=float(o['non_Apodida_exact_pct']),nondegenerate_exact=r['non_Apodida_exact_pct'],exact_change_pp=r['non_Apodida_exact_pct']-float(o['non_Apodida_exact_pct'])))
write('change_vs_degenerate.csv',deltas)
intro='''<h1>MiCucumber · 无简并版 / Nondegenerate edition</h1><p>四个区域各1对、2对，共8套无简并候选；另保留v4原版。所有序列均为5′→3′，两对按独立PCR评估。<br>Eight A/C/G/T-only portfolios plus the unchanged original v4 control. Two pairs mean separate PCRs, not a validated multiplex.</p><p><b>计算候选，尚无湿实验验证 / Computational candidates; no wet-lab validation.</b></p>'''
intro += '<p><b>结果判断 / Interpretation:</b> 无简并化显著降低覆盖与完全匹配；此版保留为实验对照，不替代当前简并版。原版v4覆盖较高，但非目标命中很多。 / Removing degeneracy substantially reduces coverage and exact matching. Retain these as experimental comparators, not replacements for the degenerate portfolios. Original v4 has higher target coverage but extensive background hits.</p>'
method='''<h2>方法与边界 / Methods and limits</h2><p>枚举当前四区域精简方案中8个简并配对的所有具体序列组合；不进行任意正反引物跨亲本重组或新位置搜索。剔除50/200 nM下预测结构Tm≥55°C的组合。对每区域穷举1对及2对方案，先最大化共同面板与本区域面板的非Apodida平均覆盖，再在两面板各自容差内最大化完全匹配率。v4opt/M两对容差2个百分点，其余1个百分点。最优性仅限这一候选池和目标函数；并未证明全局最优。非目标由全序列双链扫描复核，WC≤3和GT≤2各≤5条背景记录。</p><p>Enumerate concrete variants of the eight frozen parent pairs, with no cross-parent F/R recombination or new binding sites. Exhaustively compare one-/two-pair subsets after a structural Tm &lt;55°C filter at 50 and 200 nM per oligo. Optimize mean non-Apodida coverage on common and own-region panels, then exact matching within 1 pp of each panel's coverage anchor (2 pp for v4opt/M two-pair sets). Conditional optimum only. Independently recheck whole-sequence target and background hits.</p><p>覆盖：每条引物≤2处错配且3′末端3 nt完全匹配；完全匹配：正反均0错配。共同面板151个名称标签、351个标签内单倍型，非Apodida为145个标签；按标签及标签内单倍型等权。名称未经同物异名统一。背景5,600条，命中为accession数而非reads比例。WC≤4为更宽松的残余风险检查；GT为允许G–T配对的敏感性模型。v4原版不受新候选非目标门槛约束。设计与评估共用参考库，不能当作独立外部验证。</p><p>Coverage permits ≤2 mismatches per primer with the terminal 3 nt exact; exact requires zero mismatches in both primers. Common panel: 151 taxonomic name labels / 351 within-label haplotypes; 145 non-Apodida labels. Equal label and within-label haplotype weights; synonyms not reconciled. Background counts refer to 5,600 reference accessions, not read fractions. WC≤4 exposes relaxed residual risk; GT permits G–T pairing. Original v4 is an unconstrained historical control. The reference set is shared between design and evaluation.</p>'''
headers=['方案 / Portfolio','非Apodida覆盖 / Coverage','完全匹配 / Exact','含Apodida覆盖 / All coverage','含Apodida完全匹配 / All exact','WC≤3','GT≤2','WC≤4']
trs=[]
for r in comparison:
 if r['panel']=='common':trs.append('<tr><td>'+html.escape(r['scheme'])+'</td>'+''.join(f'<td>{r[k]:.2f}%</td>' for k in ('non_Apodida_coverage_pct','non_Apodida_exact_pct','coverage_pct','exact_pct'))+''.join(f'<td>{r[k]}</td>' for k in ('WC_le3','GT_le2','WC_le4'))+'</tr>')
sequence_table='<h2>引物序列 / Primer sequences (5′→3′)</h2><table><tr><th>方案 / Portfolio</th><th>PCR</th><th>F</th><th>R</th></tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r[k]))+'</td>' for k in ('scheme','reaction','F','R'))+'</tr>' for r in seq)+'</table>'
links='<h2>下载 / Downloads</h2><p>'+ ' · '.join(f'<a href="{n}">{label}</a>' for n,label in [('primer_pairs.csv','配对序列 CSV'),('primers.fasta','FASTA'),('v4_original.fasta','v4 原版'),('comparison.csv','双面板比较'),('change_vs_degenerate.csv','与简并版差值'),('missed_taxa.csv','漏检类群'),('offtargets.csv','非目标命中'),('thermodynamics.csv','热力学'),('selection_audit.csv','筛选记录'),('reproducibility.zip','完整复现包'),('validation.json','复核记录')])+'</p>'
page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MiCucumber nondegenerate</title><style>body{max-width:1400px;margin:40px auto;padding:0 24px;font:16px/1.65 system-ui;color:#16352f;background:#f7faf8}table{border-collapse:collapse;background:white;width:100%;font-size:13px}td,th{padding:10px;border-bottom:1px solid #cbdad3;text-align:left}th{background:#dcece3}h1,h2{color:#14684b}td{overflow-wrap:anywhere}a{color:#14684b}p{max-width:1100px}</style>'+intro+'<h2>共同面板 / Common-panel comparison</h2><table><tr>'+''.join('<th>'+s+'</th>' for s in headers)+'</tr>'+''.join(trs)+'</table>'+links+method+sequence_table+'<p>Copyright © 2026 Fei Xia (GUIBA-EX). All rights reserved. <a href="COPYRIGHT.md">著作权声明 / Copyright</a></p></html>'
(out/'report.html').write_text(page)
print(json.dumps(validation,indent=2));print('Common-panel results:')
for r in comparison:
 if r['panel']=='common':print(r)
