"""Rebuild the nondegenerate design and independently scan target/background records.
Requires Python 3.12+, NumPy, Biopython, primer3-py and a C++17 compiler.
"""
from pathlib import Path
import subprocess,sys,os,csv,json,math
p=Path(__file__).resolve().parent
run=p/'rebuild';result=run/'results';run.mkdir(exist_ok=True)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1')
def call(args):subprocess.run([str(x) for x in args],check=True,cwd=p,env=env)
call([sys.executable,p/'design.py',p/'input',run])
import shutil
for n in ('target.fasta','background.fasta'):shutil.copy2(p/'input'/n,run/n)
call([os.environ.get('CXX','c++'),'-O3','-std=c++17',p/'independent_scan.cpp','-o',run/'independent_scan'])
call([run/'independent_scan',run])
call([sys.executable,p/'summarize.py',p/'input',run,result])
assert json.loads((result/'schemes.json').read_text())==json.loads((p/'expected/schemes.json').read_text())
def table(path):return list(csv.DictReader(path.open()))
assert table(result/'primer_pairs.csv')==table(p/'expected/primer_pairs.csv')
a,b=table(result/'comparison.csv'),table(p/'expected/comparison.csv');assert len(a)==len(b)
for x,y in zip(a,b):
 for k in x:
  if k.endswith('_pct'):assert math.isclose(float(x[k]),float(y[k]),abs_tol=1e-8),(k,x,y)
  else:assert x[k]==y[k],(k,x,y)
print('PASS: reproduced selection, sequences, metrics and independent scan agreement.')
