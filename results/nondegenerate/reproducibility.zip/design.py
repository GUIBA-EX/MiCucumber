"""Enumerate concrete variants of frozen compact parents; optimize independent PCR unions.
Usage: python design.py INPUT_DIR OUTPUT_DIR
INPUT_DIR: target/background FASTA, metadata/taxonomy, target_detail.tsv,
compact_parents.csv, baselines.json. No network required.
"""
from pathlib import Path
import sys,csv,json,itertools,collections,functools
import numpy as np
from Bio.Data.IUPACData import ambiguous_dna_values as I
from scan_core import database,flexible_hits,rc,B
import primer3
src=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def read(n,sep=','):return list(csv.DictReader((src/n).open(),delimiter=sep))
def write(n,rr):
 with (out/n).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
parents=[r for r in read('compact_parents.csv') if r['pairs']=='2']
tax={r['accession']:r for r in read('target_taxonomy.tsv','\t')}
tab=collections.defaultdict(dict)
for r in read('target_detail.tsv','\t'):tab[r['name'],r['panel']][r['accession']]=r
D=database(src/'target.fasta');arr,offsets,ends,refs,prefix=D
@functools.lru_cache(None)
def hits(q,side):
 result={};pq=q if side=='F' else rc(q)
 for rec,hh in flexible_hits(D,q,side,2,False).items():
  rr=[]
  for pos,mm,_,amb in hh:
   if amb:continue
   if not all(arr[offsets[rec]+pos+j]&B[pq[j]] for j in (range(len(q)-3,len(q)) if side=='F' else range(3))):continue
   rr.append((pos,mm))
  if rr:result[rec]=rr
 return result
@functools.lru_cache(None)
def predict(F,R):
 fh,rh=hits(F,'F'),hits(R,'R');cov=set();ex=set()
 for rec in fh.keys()&rh.keys():
  for f,fm in fh[rec]:
   for r,rm in rh[rec]:
    if r-f-len(F)>=50 and 150<=r+len(R)-f<=500:
     cov.update(refs[rec]['accessions'])
     if fm==rm==0:ex.update(refs[rec]['accessions'])
 return cov,ex
@functools.lru_cache(None)
def single(q,c):
 kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=c)
 return primer3.calc_tm(q,**kw),max(primer3.calc_hairpin(q,**kw).tm,primer3.calc_homodimer(q,**kw).tm)
def thermal(F,R):
 rr=[]
 for c in (50,200):
  ft,fs=single(F,c);rt,rs=single(R,c)
  hetero=primer3.calc_heterodimer(F,R,mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=c).tm
  rr.append(dict(concentration_nM=c,F_tm=ft,R_tm=rt,delta_tm=abs(ft-rt),structure_max=max(fs,rs,hetero)))
 return rr
candidates=[];chosen=[];predictions={};thermal_rows=[];audit=[]
for loc in ('v4opt','S','M','L'):
 locus='MiCucumber-'+loc;pp=[r for r in parents if r['version']==locus];pool={}
 for p in pp:
  for F in map(''.join,itertools.product(*(I[c] for c in p['F']))):
   for R in map(''.join,itertools.product(*(I[c] for c in p['R']))):pool.setdefault((F,R),[]).append(p['pair_id'])
 ids=sorted(set(tab[pp[0]['pair_id'],'common'])|set(tab[pp[0]['pair_id'],'own_region']))
 non=np.array([tax[k]['order']!='Apodida' for k in ids]);weights={pn:np.array([float(tab[pp[0]['pair_id'],pn].get(k,{}).get('weight',0)) for k in ids]) for pn in ('common','own_region')}
 nw={pn:w*non/(w*non).sum() for pn,w in weights.items()}
 cc=[];ee=[];feasible=[]
 for i,((F,R),par) in enumerate(sorted(pool.items())):
  th=thermal(F,R);name=f'ND_{loc}_{i:04d}';cov,ex=predict(F,R)
  # Retain the prior structural ceiling; record Tm differences rather than claim an annealing temperature.
  ok=max(r['structure_max'] for r in th)<55
  row=dict(name=name,locus=locus,F=F,R=R,parent_ids=';'.join(par),thermal_pass=ok,max_delta_tm=max(r['delta_tm'] for r in th),max_structure_tm=max(r['structure_max'] for r in th))
  cv=np.array([k in cov for k in ids]);ev=np.array([k in ex for k in ids])
  for pn in weights:
   row[pn+'_nonapo_coverage_pct']=100*float(nw[pn][cv].sum());row[pn+'_nonapo_exact_pct']=100*float(nw[pn][ev].sum())
  candidates.append(row)
  if ok:
   feasible.append(row);cc.append(cv);ee.append(ev)
  if i%200==0:print(loc,i,'/',len(pool),flush=True)
 C=np.array(cc,dtype=float);E=np.array(ee,dtype=float);N=len(feasible)
 # Exact exhaustive one-/two-pair comparison; union = marginal sums minus intersection.
 cm={pn:C@w for pn,w in nw.items()};em={pn:E@w for pn,w in nw.items()}
 for count in (1,2):
  ix,jx=(np.arange(N),np.arange(N)) if count==1 else np.triu_indices(N,1)
  cv={pn:cm[pn][ix] if count==1 else (cm[pn][:,None]+cm[pn][None,:]-(C*w)@C.T)[ix,jx] for pn,w in nw.items()}
  ev={pn:em[pn][ix] if count==1 else (em[pn][:,None]+em[pn][None,:]-(E*w)@E.T)[ix,jx] for pn,w in nw.items()}
  cavg=(cv['common']+cv['own_region'])/2;eavg=(ev['common']+ev['own_region'])/2
  anchor=np.lexsort((eavg,cavg))[-1];tol=2 if count==2 and loc in ('v4opt','M') else 1
  allowed=np.flatnonzero((cv['common']>=cv['common'][anchor]-tol/100-1e-10)&(cv['own_region']>=cv['own_region'][anchor]-tol/100-1e-10))
  best=allowed[np.lexsort((cavg[allowed],eavg[allowed]))[-1]]
  indices=[int(ix[best])] if count==1 else [int(ix[best]),int(jx[best])]
  scheme=f'MiCucumber-{loc}-ND-{count}pair';rr=[feasible[i] for i in indices]
  chosen.append(dict(name=scheme,locus=locus,count=count,pair_names=[r['name'] for r in rr],parent_panel_pair=pp[0]['pair_id'],tolerance_pp=tol))
  audit.append(dict(scheme=scheme,enumerated_variants=len(pool),thermal_eligible=N,enumerated_combinations=len(ix),anchor_common_coverage=100*cv['common'][anchor],anchor_own_coverage=100*cv['own_region'][anchor],chosen_common_coverage=100*cv['common'][best],chosen_own_coverage=100*cv['own_region'][best]))
  for row in rr:
   cov,ex=predict(row['F'],row['R']);predictions[row['name']]=dict(coverage=sorted(cov),exact=sorted(ex))
 print(loc,'selected',chosen[-2:],flush=True)
write('candidate_scores.csv',candidates);write('selection_audit.csv',audit)
selected_names={n for s in chosen for n in s['pair_names']};selected=[r for r in candidates if r['name'] in selected_names]
base=json.loads((src/'baselines.json').read_text())[0]
assert base['name']=='MiCucumber_v4'
selected.append(dict(base,locus='original-v4'))
chosen.append(dict(name='MiCucumber-v4-original',locus='original-v4',count=1,pair_names=[base['name']],parent_panel_pair=base['name'],tolerance_pp=None))
# Preserve v4 exactly, including its IUPAC degeneracies; use independent prior predictions for comparison.
for row in selected:
 if row['name']!=base['name']:
  for t in thermal(row['F'],row['R']):thermal_rows.append(dict(name=row['name'],**t))
(out/'selected_pairs.json').write_text(json.dumps(selected,indent=2));(out/'schemes.json').write_text(json.dumps(chosen,indent=2));(out/'predictions.json').write_text(json.dumps(predictions))
write('thermodynamics.csv',thermal_rows)
with (out/'independent_primers.tsv').open('w') as f:
 for r in selected:f.write(f"{r['name']}\t{r['F']}\t{r['R']}\n")
print('Finished',len(candidates),'concrete candidates;',len(selected)-1,'unique selected pairs + original v4',flush=True)
