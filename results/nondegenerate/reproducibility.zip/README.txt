MiCucumber nondegenerate reproduction / 无简并版复现

Install requirements.txt and a C++17 compiler; run python run_reproduction.py.
安装 requirements.txt 中的依赖及 C++17 编译器；运行 python run_reproduction.py。
The script re-enumerates 2,644 concrete candidates, selects eight portfolios, re-scans all frozen target/background sequences, and checks results against expected tables. Original v4 remains unchanged.
脚本重新枚举2,644个候选、筛选8套方案、全序列复核并与预期表比较；v4原版不变。
No network is required after dependency installation. Biological evaluation is not independent holdout validation. Separate PCRs only; no wet-lab validation.
依赖安装后无需联网。计算复核不代表独立留出验证；两对为独立PCR，尚无湿实验验证。
