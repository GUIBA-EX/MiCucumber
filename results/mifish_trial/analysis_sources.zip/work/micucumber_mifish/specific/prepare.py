from pathlib import Path
import csv,json,collections,sys
import numpy as np
from Bio import SeqIO
from Bio.Seq import Seq
p=Path(__file__).resolve().parent;root=p.parents[2]
rr=list(csv.DictReader((p.parent/'oligo_candidates.csv').open()));panel=json.loads((p.parent/'panel.json').read_text());seq={r.id:str(r.seq).upper() for r in SeqIO.parse(root/'work/micucumber_round2/optimization/target_aligned.fasta','fasta')};cols=[i for i,b in enumerate(seq['AB525437.1']) if b!='-'];w=np.array([float(r['weight']) for r in panel]);w/=w.sum()
rows=[];states={};seen=set()
for r in rr:
 a,b=int(r['start']),int(r['end']);windows=[seq[x['accession']][cols[a-1]:cols[b-1]+1] for x in panel]
 if r['side']=='R':windows=[str(Seq(s).reverse_complement()) for s in windows]
 freq=collections.Counter()
 for s,weight in zip(windows,w):
  if len(s)==len(r['sequence']) and set(s)<=set('ACGT'):freq[s]+=weight
 variants=[r['sequence']]+[s for s,_ in freq.most_common(3)]
 for q in variants:
  key=(r['region'],r['side'],q)
  if key in seen:continue
  seen.add(key)
  gc=sum(c in 'GC' for c in q)/len(q)
  if not .35<=gc<=.65 or any(c*6 in q for c in 'ACGT'):continue
  cv=[];ex=[]
  for s in windows:
   ok=len(s)==len(q) and set(s)<=set('ACGT');cv.append(ok and s[-3:]==q[-3:] and sum(x!=y for x,y in zip(q,s))<=2);ex.append(s==q)
  if w@cv<.05:continue
  name=f'O{len(rows):04d}';rows.append(dict(name=name,region=r['region'],side=r['side'],sequence=q,start=a,end=b,coverage=float(w@cv),exact=float(w@ex),terminal_GC=q[-1] in 'GC'));states[name]=dict(coverage=cv,exact=ex)
with (p/'oligos.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
(p/'oligo_states.json').write_text(json.dumps(states));(p/'oligos.tsv').write_text(''.join(f"{r['name']} {r['side']} {r['sequence']}\n" for r in rows));print('oligos',len(rows))
