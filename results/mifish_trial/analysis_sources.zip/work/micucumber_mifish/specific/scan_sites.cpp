// Independent exhaustive all-window scanner: no tail prefilter, no Python scanner imports.
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <set>
#include <algorithm>
using namespace std;
int mask(char c){switch(c){case'A':return 1;case'C':return 2;case'G':return 4;case'T':return 8;case'R':return 5;case'Y':return 10;case'S':return 6;case'W':return 9;case'K':return 12;case'M':return 3;case'B':return 14;case'D':return 13;case'H':return 11;case'V':return 7;default:return 15;}}
int comp(int x){return ((x&1)?8:0)|((x&2)?4:0)|((x&4)?2:0)|((x&8)?1:0);}
struct Rec{string id;vector<int>s;};
vector<Rec> fasta(string f){ifstream in(f);string l;vector<Rec> r;while(getline(in,l)){if(l.empty())continue;if(l[0]=='>'){istringstream ss(l.substr(1));string id;ss>>id;r.push_back({id,{}});}else for(char c:l)if(!isspace(c))r.back().s.push_back(mask(toupper(c)));}return r;}
struct Hit{int pos,mm,last3,amb;};
vector<int> primer(string q,bool reverse,bool gt){vector<int> m;for(char c:q)m.push_back(mask(c));if(reverse){std::reverse(m.begin(),m.end());for(auto &x:m)x=comp(x);}if(gt)for(auto&x:m){int old=x;if(!reverse){if(old&4)x|=1;if(old&8)x|=2;}else{if(old&2)x|=8;if(old&1)x|=4;}}return m;}
vector<Hit> scan(const vector<int>&s,const vector<int>&q,bool reverse,int limit){vector<Hit> h;for(int i=0;i+(int)q.size()<=(int)s.size();i++){int mm=0,m3=0,amb=0;for(int j=0;j<(int)q.size();j++){int x=s[i+j];amb+=x!=1&&x!=2&&x!=4&&x!=8;int mis=(x&q[j])==0;mm+=mis;if(reverse?j<3:j>=(int)q.size()-3)m3+=mis;if(mm>limit)break;}if(mm<=limit)h.push_back({i,mm,m3,amb});}return h;}
int main(int argc,char**argv){string root=argv[1];ifstream in(root+"/oligos.tsv");ofstream out(root+"/background_sites.tsv");auto records=fasta(root+"/../background.fasta");string name,side,q;int count=0;while(in>>name>>side>>q){for(int gt=0;gt<2;gt++){auto pr=primer(q,side=="R",gt);for(auto &rec:records)for(int ori=0;ori<2;ori++){auto s=rec.s;if(ori){reverse(s.begin(),s.end());for(auto&x:s)x=comp(x);}for(auto &h:scan(s,pr,side=="R",gt?2:4))if(!h.amb)out<<name<<'\t'<<rec.id<<'\t'<<ori<<'\t'<<gt<<'\t'<<h.pos<<'\t'<<h.mm<<'\t'<<h.last3<<'\n';}}if(++count%100==0)cerr<<count<<" oligos done\n";}}