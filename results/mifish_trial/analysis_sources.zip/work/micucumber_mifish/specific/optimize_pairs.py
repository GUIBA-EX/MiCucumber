from pathlib import Path
import sys,csv,json,collections,itertools
import numpy as np
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p.parent/'deps'));import primer3
rows=list(csv.DictReader((p/'oligos.csv').open()));states=json.loads((p/'oligo_states.json').read_text());panel=json.loads((p.parent/'panel.json').read_text());w=np.array([float(r['weight']) for r in panel]);w/=w.sum()
kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=200)
for r in rows:
 q=r['sequence'];r['tm']=primer3.calc_tm(q,**kw);r['structure']=max(primer3.calc_hairpin(q,**kw).tm,primer3.calc_homodimer(q,**kw).tm)
# Preserve strict 3' match on targets, but do not require it on background.
sites=collections.defaultdict(lambda:collections.defaultdict(list))
for line in (p/'background_sites.tsv').open():
 name,acc,ori,gt,pos,mm,last3=line.split();sites[name,int(gt)][acc,ori].append((int(pos),int(mm)))
print('sites loaded',flush=True)
def bg(f,r,gt,limit):
 fh=sites[f['name'],gt];rh=sites[r['name'],gt];result=set();L=len(f['sequence'])
 for key in fh.keys()&rh.keys():
  if any(fm<=limit and rm<=limit and 0<=rp-fp-L<=1000 for fp,fm in fh[key] for rp,rm in rh[key]):result.add(key[0])
  if len(result)>5:return result
 return result
selected=[];audits=[];feasible_all=[]
for reg in ['S','M','L','XL']:
 fs=[r for r in rows if r['region']==reg and r['side']=='F' and float(r['structure'])<55];rs=[r for r in rows if r['region']==reg and r['side']=='R' and float(r['structure'])<55];pairs=[]
 for f,r in itertools.product(fs,rs):
  if abs(f['tm']-r['tm'])>5:continue
  cv=np.array(states[f['name']]['coverage'])&states[r['name']]['coverage'];ex=np.array(states[f['name']]['exact'])&states[r['name']]['exact'];score=float(w@cv)
  if score<.05:continue
  pairs.append((score,float(w@ex),f,r,cv,ex))
 pairs.sort(key=lambda x:(x[0],x[1]),reverse=True);valid=[]
 for score,exact,f,r,cv,ex in pairs:
  a=bg(f,r,0,3)
  if len(a)>5:continue
  b=bg(f,r,1,2)
  if len(b)>5:continue
  ht=primer3.calc_heterodimer(f['sequence'],r['sequence'],**kw).tm
  if ht>=55:continue
  valid.append(dict(region=reg,F=f['sequence'],R=r['sequence'],F_id=f['name'],R_id=r['name'],coverage=score,exact=exact,F_tm=f['tm'],R_tm=r['tm'],WC3=sorted(a),GT2=sorted(b),cv=cv,ex=ex))
 print(reg,'pairs',len(pairs),'eligible',len(valid),flush=True);audits.append(dict(region=reg,tested=len(pairs),eligible=len(valid)))
 # Collapse identical coverage/exact/background states; retain smallest Tm difference.
 distinct={}
 for r in valid:
  key=(r['cv'].tobytes(),r['ex'].tobytes(),tuple(r['WC3']),tuple(r['GT2']))
  if key not in distinct or abs(r['F_tm']-r['R_tm'])<abs(distinct[key]['F_tm']-distinct[key]['R_tm']):distinct[key]=r
 valid=list(distinct.values())
 print(reg,'distinct states',len(valid),flush=True)
 # Exact union search over distinct surviving states, prioritize coverage then exact.
 if not valid:continue
 best1=max(valid,key=lambda r:(r['coverage'],r['exact']));best=(best1['coverage'],best1['exact']);pick=[best1]
 for a,b in itertools.combinations(valid,2):
  if len(set(a['WC3'])|set(b['WC3']))>5 or len(set(a['GT2'])|set(b['GT2']))>5:continue
  score=(float(w@(a['cv']|b['cv'])),float(w@(a['ex']|b['ex'])))
  if score>best:best=score;pick=[a,b]
 for count,pp,score in [(1,[best1],(best1['coverage'],best1['exact'])),(2,pick,best)]:
  for i,r in enumerate(pp):selected.append({k:v for k,v in dict(r,option=count,component=i+1,union_coverage=score[0],union_exact=score[1]).items() if k not in ['cv','ex']})
 for r in valid:feasible_all.append({k:v for k,v in r.items() if k not in ['cv','ex']})
(p/'selection.json').write_text(json.dumps(selected,indent=2));(p/'audit.json').write_text(json.dumps(audits,indent=2));(p/'feasible.json').write_text(json.dumps(feasible_all))
print('DONE',flush=True)
