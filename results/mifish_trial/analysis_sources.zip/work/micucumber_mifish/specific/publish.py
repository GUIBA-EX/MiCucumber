from pathlib import Path
import json,csv,html,shutil
from Bio import SeqIO
from Bio.Seq import Seq
p=Path(__file__).resolve().parent;root=p.parents[2];out=root/'outputs/MiCucumber_MiFish_trial';out.mkdir(exist_ok=True)
selected=json.loads((p/'selection.json').read_text());oligos={r['name']:r for r in csv.DictReader((p/'oligos.csv').open())};panel=json.loads((p.parent/'panel.json').read_text());seq={r.id:str(r.seq).upper() for r in SeqIO.parse(root/'work/micucumber_round2/optimization/target_aligned.fasta','fasta')};cols=[i for i,b in enumerate(seq['AB525437.1']) if b!='-'];pages=[]
for region in ['S','M','L','XL']:
 rr=[r for r in selected if r['region']==region];seen=set();parts=[]
 for r in rr:
  key=(r['F'],r['R'])
  if key in seen:continue
  seen.add(key)
  for side in ['F','R']:
   ol=oligos[r[side+'_id']];q=r[side];a,b=int(ol['start']),int(ol['end']);groups={}
   for item in panel:
    s=seq[item['accession']][cols[a-1]:cols[b-1]+1]
    if side=='R':s=str(Seq(s).reverse_complement())
    key=(item['order'],s);groups.setdefault(key,[]).append(item)
   body=f'<h3>{region} {side} — {q}</h3><p>引物及同向参考序列均按5′→3′显示；R参考已反向互补。蓝色为相同碱基，橙色为错配，紫色为可能的G–T配对；末端3 nt以边框标明。缺口保留，不计为匹配。相同目内相同结合序列合并显示。</p><table><tr><th>类群 / 代表序列（记录数）</th><th>5′ → 3′</th></tr>'
   body+='<tr><th>Primer</th><td>'+''.join(f'<span class="base {"tail" if i>=len(q)-3 else ""}">{x}</span>' for i,x in enumerate(q))+'</td></tr>'
   for (order,s),items in sorted(groups.items()):
    cells=''
    for i,x in enumerate(s):
     c='match' if len(s)==len(q) and x==q[i] else 'gt' if len(s)==len(q) and (q[i],x) in [('G','A'),('T','C')] else 'miss'
     cells+=f'<span class="base {c} {"tail" if len(s)==len(q) and i>=len(q)-3 else ""}">{x}</span>'
    body+=f'<tr><td>{html.escape(order+" / "+items[0]["organism"]+" / "+items[0]["accession"])} ({len(items)})</td><td>{cells}</td></tr>'
   parts.append(body+'</table>')
 if not parts:parts=['<p>本轮候选中没有通过背景和热力学门槛的配对。</p>']
 pages.append(f'<h2>{region}</h2>'+''.join(parts))
style='<style>body{font:16px system-ui;margin:32px;color:#173647}table{border-collapse:collapse;margin:20px 0}td,th{padding:5px;text-align:left;border-bottom:1px solid #ddd}td:nth-child(2){white-space:nowrap}.base{display:inline-block;font:15px monospace;width:17px;text-align:center;padding:4px 0}.match{background:#d7edf5}.miss{background:#ffd3a3}.gt{background:#e5d6fa}.tail{border-bottom:3px solid #153a50}p{max-width:1000px}</style>'
(out/'base_matching.html').write_text('<meta charset="utf-8"><title>MiCucumber碱基匹配图</title>'+style+'<h1>MiCucumber：新候选碱基匹配图</h1><p>探索性候选，待独立复核；面板排除Apodida。逐碱基对齐用于解释结合位点，不替代全序列产物扫描。</p>'+''.join(pages))
if selected:
 with (out/'specific_candidates.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(selected[0]));w.writeheader();w.writerows(selected)
shutil.copy2(p/'audit.json',out/'specific_audit.json')
