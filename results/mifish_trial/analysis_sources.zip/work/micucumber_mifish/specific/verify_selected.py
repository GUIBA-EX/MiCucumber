from pathlib import Path
import json,csv,subprocess
p=Path(__file__).resolve().parent;rr=json.loads((p/'selection.json').read_text());seen={}
for r in rr:seen.setdefault((r['F'],r['R']),f'New_{r["region"]}_{len(seen):02}')
rows=[dict(name=n,F=f,R=r) for (f,r),n in seen.items()]
for r in csv.DictReader((p.parents[2]/'outputs/MiCucumber/sequences/primer_pairs.csv').open()):
 if r['pair_name'] not in [x['name'] for x in rows]:rows.append(dict(name=r['pair_name'],F=r['F'],R=r['R']))
v=p/'verify';v.mkdir(exist_ok=True)
for role in ['target','background']:
 f=v/(role+'.fasta')
 if not f.exists():f.symlink_to((p.parent/(role+'.fasta')).resolve())
(v/'independent_primers.tsv').write_text(''.join(f"{r['name']}\t{r['F']}\t{r['R']}\n" for r in rows));(v/'pairs.json').write_text(json.dumps(rows))
subprocess.run([str(p.parents[1]/'micucumber_nondegenerate/independent_scan'),str(v)],check=True)
