from pathlib import Path
import json,csv,collections,shutil,hashlib
p=Path(__file__).resolve().parent;out=p.parents[2]/'outputs/MiCucumber_MiFish_trial';panel=json.loads((p.parent/'panel.json').read_text());w={r['accession']:float(r['weight']) for r in panel};den=sum(w.values());rows=json.loads((p/'selection.json').read_text());pairs=json.loads((p/'verify/pairs.json').read_text());names={(r['F'],r['R']):r['name'] for r in pairs};hits=collections.defaultdict(set)
for r in csv.DictReader((p/'verify/independent_hits.tsv').open(),delimiter='\t'):
 for k in ['exact','le2last3','le2','le3','le4']:
  if r[k]=='1':hits[r['name'],r['role'],r['model'],k].add(r['accession'])
def summary(ns):
 def union(role,model,k):return set().union(*(hits[n,role,model,k] for n in ns))
 cv=union('target','WC','le2last3');ex=union('target','WC','exact')
 return dict(coverage=100*sum(w.get(a,0) for a in cv)/den,exact=100*sum(w.get(a,0) for a in ex)/den,WC3=len(union('background','WC','le3')),GT2=len(union('background','GT','le2')),WC4=len(union('background','WC','le4')))
results=[];missed=[]
for reg in ['S','M','L','XL']:
 for count in [1,2]:
  rr=[r for r in rows if r['region']==reg and r['option']==count]
  old=[reg] if count==1 else [reg+'A',reg+'B'];results.append(dict(region=reg,version='current',pairs=count,**summary(old)))
  if not rr:continue
  ns=[names[r['F'],r['R']] for r in rr];s=summary(ns);assert s['WC3']<=5 and s['GT2']<=5
  results.append(dict(region=reg,version='trial',pairs=len(rr),**s))
  cv=set().union(*(hits[n,'target','WC','le2last3'] for n in ns))
  for item in panel:
   if item['accession'] not in cv:missed.append(dict(region=reg,option=count,**item))
for file,rs in [('verified_comparison.csv',results),('missed_references.csv',missed)]:
 with (out/file).open('w') as f:
  wr=csv.DictWriter(f,fieldnames=list(rs[0]));wr.writeheader();wr.writerows(rs)
lines=['# MiCucumber：MiFish思路第二轮试验','', '共同面板、非Apodida加权统计。所有下表结果均来自全序列双链扫描；新候选未替换正式发布序列。','', '| 长度 | 版本 | 对数 | 覆盖率 | 完全匹配率 | WC≤3 | GT≤2 | WC≤4 |','|---|---|---:|---:|---:|---:|---:|---:|']
for r in results:lines.append(f"| {r['region']} | {r['version']} | {r['pairs']} | {r['coverage']:.2f}% | {r['exact']:.2f}% | {r['WC3']} | {r['GT2']} | {r['WC4']} |")
lines+=['','## 方法与结果解释','','在参考窗口起点±15 nt内搜索20–30 nt引物，增加常见真实结合序列，取得1,343条候选。按目标3′末端3 nt完全匹配、每引物最多2处错配筛选；背景使用更宽松的WC≤3与GT≤2模型，组合并集各≤5条。正反Tm差≤5°C，200 nM条件下结构Tm<55°C。穷举可行候选的单对与两对并集；两对按独立PCR解释。','','L没有通过本轮全部约束的新候选，保留现有方案。新候选覆盖与完全匹配可能存在取舍，不能将覆盖上升解释为两项都改善。这里只优化共同面板；区域面板、分辨率、带接头及混合体系验证仍需补充。','','## 碱基匹配图','','[完整逐碱基匹配图](base_matching.html)：保留实际碱基与缺口，标明3′端。静态图展示各目最常见的结合序列；完整HTML列出目内所有不同结合序列。']
for reg in ['S','M','XL']:lines+=['',f'![{reg}](base_matching_{reg}.png)']
lines+=['','[候选序列](specific_candidates.csv) · [独立扫描比较](verified_comparison.csv) · [漏检参考](missed_references.csv)','','设计依据：[Miya et al. 2015](https://doi.org/10.1098/rsos.150088)。G–T只作为单独敏感性模型，不算严格完全匹配。']
(out/'README.md').write_text('\n'.join(lines)+'\n');shutil.copy2(p/'verify/independent_hits.tsv',out/'independent_hits.tsv');(out/'candidate_primers.fasta').write_text(''.join(f">{names[r['F'],r['R']]}_{side}\n{r[side]}\n" for i,r in enumerate(rows) if (r['F'],r['R']) not in [(x['F'],x['R']) for x in rows[:i]] for side in ['F','R']))
print(json.dumps(results,indent=2))
