exec((__import__('pathlib').Path(__file__).parent/'publish.py').read_text())
import sys,os
sys.path.insert(0,str(root/'work/plotdeps'));os.environ['MPLCONFIGDIR']=str(p/'mplcache')
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
for reg in ['S','M','L','XL']:
 rr=[r for r in selected if r['region']==reg and r['option']==2]
 if not rr:continue
 fig,axes=plt.subplots(len(rr)*2,1,figsize=(15,5*len(rr)*2),squeeze=False)
 for ax,(r,side) in zip(axes[:,0],[(r,s) for r in rr for s in ['F','R']]):
  ol=oligos[r[side+'_id']];q=r[side];a,b=int(ol['start']),int(ol['end']);groups={}
  for item in panel:
   s=seq[item['accession']][cols[a-1]:cols[b-1]+1]
   if side=='R':s=str(Seq(s).reverse_complement())
   groups.setdefault(item['order'],{}).setdefault(s,[]).append(item)
  # Representative of each order = most frequent binding string by panel weight.
  records=[]
  for order,g in sorted(groups.items()):
   s,items=max(g.items(),key=lambda kv:sum(float(x['weight']) for x in kv[1]));records.append((order+' | '+items[0]['accession'],s))
  records=[('Primer 5\u2032 to 3\u2032',q)]+records
  for y,(label,s) in enumerate(records):
   ax.text(-.5,y+.5,label,ha='right',va='center',fontsize=10)
   for x,ch in enumerate(s):
    color='#d7edf5' if len(s)==len(q) and ch==q[x] else '#e5d6fa' if len(s)==len(q) and (q[x],ch) in [('G','A'),('T','C')] else '#ffd3a3'
    ax.add_patch(Rectangle((x,y),1,1,facecolor=color,edgecolor='white'));ax.text(x+.5,y+.5,ch,ha='center',va='center',fontfamily='monospace',fontsize=11)
  ax.add_patch(Rectangle((len(q)-3,0),3,len(records),fill=False,edgecolor='#173647',linewidth=2));ax.set_xlim(-16,max(len(q),max(len(s) for _,s in records))+1);ax.set_ylim(len(records)+.2,-.8);ax.axis('off');ax.set_title(f'{reg} candidate {r["component"]} / {side}: reference {a}-{b}',loc='left')
 fig.suptitle('Base matching | blue: match; orange: mismatch; purple: possible G-T\nBox: primer terminal 3 nt. Most frequent binding sequence per order; full records in HTML.',fontsize=12)
 fig.tight_layout(rect=[0,0,1,.96]);fig.savefig(out/f'base_matching_{reg}.png',dpi=160);fig.savefig(out/f'base_matching_{reg}.svg');plt.close(fig)
