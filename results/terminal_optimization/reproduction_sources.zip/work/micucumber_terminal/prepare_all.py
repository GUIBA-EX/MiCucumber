from common import *
rows=json.loads((p/'all_oligos.json').read_text());rows=[r for r in rows if all(t[2]<55 for t in oligo_thermal(r['sequence']))];(p/'oligos.json').write_text(json.dumps(rows));(p/'sites/oligos.tsv').write_text(''.join(f"{r['id']} {r['side']} {r['sequence']}\n" for r in rows));print('screened oligos',len(rows),flush=True)
