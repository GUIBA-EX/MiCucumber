from common import *
import collections
rr=json.loads((p/'selected.json').read_text());out=p/'release';out.mkdir(exist_ok=True)
def audit(name,side,q,stage):
 vs=expand(q);runs=[max(len(list(g)) for _,g in itertools.groupby(s)) for s in vs];gc5=[sum(c in 'GC' for c in s[-5:]) for s in vs];gc3=[sum(c in 'GC' for c in s[-3:]) for s in vs];ends=[len(list(itertools.takewhile(lambda c:c==s[-1],s[::-1]))) for s in vs];dg=[primer3.calc_end_stability(s[-5:],str(Seq(s[-5:]).reverse_complement()),dna_conc=200,temp_c=37,**kw).dg/1000 for s in vs]
 return dict(stage=stage,name=name,side=side,sequence=q,variants=len(vs),terminal_5=q[-5:],terminal_base_degenerate=len(I[q[-1]])>1,GC_last3_min=min(gc3),GC_last5_min=min(gc5),GC_last5_max=max(gc5),terminal_run_max=max(ends),homopolymer_max=max(runs),end5_dG37_min_kcal_mol=min(dg),end5_dG37_max_kcal_mol=max(dg),passes_terminal_rules=terminal(q))
rows=[audit(r['name'],side,r[side],'current') for r in rr for side in ['F','R']];assert all(r['passes_terminal_rules'] for r in rows)
frozen=p/'previous_pairs.csv'
if not frozen.exists():write(frozen,read(root/'outputs/MiCucumber/sequences/primer_pairs.csv'))
for r in read(frozen):
 for side in ['F','R']:rows.append(audit(r['pair_name'],side,r[side],'original-control' if r['chemistry']=='original' else 'previous'))
write(out/'terminal_audit.csv',rows);print('current oligos',sum(r['stage']=='current' for r in rows),'terminal-degenerate oligos',sum(r['stage']=='current' and r['terminal_base_degenerate'] for r in rows))
