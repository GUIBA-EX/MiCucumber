from common import *
import collections
rr=json.loads((p/'selected.json').read_text());out=p/'release';out.mkdir(exist_ok=True);h=collections.defaultdict(set);sizes=collections.defaultdict(list)
for r in csv.DictReader((p/'verify/independent_hits.tsv').open(),delimiter='\t'):
 for k in ['exact','le2last3','le2','le3','le4']:
  if r[k]=='1':h[r['name'],r['role'],r['model'],k].add(r['accession'])
 if r['role']=='target' and r['sizes']:sizes[r['name']]+=[int(x) for x in r['sizes'].split(',')]
controls=json.loads((p/'original.json').read_text());control=dict(controls,name='S-original',scheme='S-original',chemistry='original',option=1,degeneracy_F=deg(controls['F']),degeneracy_R=deg(controls['R']))
allrows=rr+[control];allw=np.array([float(x['weight']) for x in panel]);allw/=allw.sum();comp=[];miss=[];checks=[];bgchecks=[];aligned={x.id for x in SeqIO.parse(p/'target_aligned.fasta','fasta')}
for scheme in dict.fromkeys(x['scheme'] for x in allrows):
 pp=[x for x in allrows if x['scheme']==scheme];names=[x['name'] for x in pp]
 def union(role,model,k):return set().union(*(h[n,role,model,k] for n in names))
 cv=union('target','WC','le2last3');ex=union('target','WC','exact');cvv=np.array([a['accession'] in cv for a in panel]);exv=np.array([a['accession'] in ex for a in panel]);sz=sum([sizes[n] for n in names],[])
 row=dict(scheme=scheme,region=pp[0]['region'],chemistry=pp[0]['chemistry'],pairs=len(pp),coverage_pct=100*float(w@cvv),exact_pct=100*float(w@exv),all_target_coverage_pct=100*float(allw@cvv),all_target_exact_pct=100*float(allw@exv),WC3=len(union('background','WC','le3')),GT2=len(union('background','GT','le2')),WC4=len(union('background','WC','le4')),product_min=min(sz) if sz else '',product_max=max(sz) if sz else '')
 if scheme!='S-original':assert row['WC3']<=5 and row['GT2']<=5
 comp.append(row)
 for x in panel:
  if x['accession'] not in cv:miss.append(dict(scheme=scheme,**x))
for x in rr:
 for mode,flag in [('cv','le2last3'),('ex','exact')]:
  for i,a in enumerate(panel):
   if a['accession'] in aligned:checks.append(dict(name=x['name'],mode=mode,accession=a['accession'],prediction=x[mode][i],full_scan=a['accession'] in h[x['name'],'target','WC',flag]))
 for model,col,flag in [('WC','WC3','le3'),('GT','GT2','le2')]:bgchecks.append(dict(name=x['name'],model=model,agree=set(x[col])==h[x['name'],'background',model,flag]))
write(out/'comparison.csv',comp);write(out/'primer_pairs.csv',[{k:x[k] for k in ['scheme','region','chemistry','name','F','R','degeneracy_F','degeneracy_R']} for x in allrows]);write(out/'missed_references.csv',miss);write(out/'thermal.csv',[dict(name=x['name'],**t) for x in rr for t in x['thermal']]);(out/'primers.fasta').write_text(''.join(f">{x['name']}_{side}\n{x[side]}\n" for x in allrows for side in ['F','R']))
bad=[x for x in checks if x['prediction']!=x['full_scan']];bb=[x for x in bgchecks if not x['agree']];(out/'verification.json').write_text(json.dumps(dict(checks=len(checks),disagreements=len(bad),details=bad,background_checks=len(bgchecks),background_disagreements=len(bb),background_details=bb,alignment_missing=[x['accession'] for x in panel if x['accession'] not in aligned]),indent=2));print(json.dumps(comp,indent=2));print('disagreements',len(bad),len(bb));assert not bad and not bb
