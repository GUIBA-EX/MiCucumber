from common import *
import html,collections
rr=json.loads((p/'selected.json').read_text());ol={r['id']:r for r in json.loads((p/'combined_oligos.json').read_text())};out=p/'release';out.mkdir(exist_ok=True);seq={r.id:str(r.seq).upper() for r in SeqIO.parse(p/'target_aligned.fasta','fasta')};ref=seq['AB525437.1'].replace('-','');cols=[i for i,b in enumerate(seq['AB525437.1']) if b!='-'];positions=[]
for r in rr:
 row=dict(name=r['name'],region=r['region'],reference='AB525437.1')
 for side in ['F','R']:
  m=ol[r[side+'_id']];a,b=m['start'],m['end'];t=ref[a-1:b];t=str(Seq(t).reverse_complement()) if side=='R' else t;q=r[side];assert len(t)==len(q);row.update({side+'_start':a,side+'_end':b,side+'_sequence':q,side+'_reference_5to3':t,side+'_reference_mismatches':sum(c not in I[n] for n,c in zip(q,t))})
 row['reference_span_bp']=row['R_end']-row['F_start']+1;positions.append(row)
write(out/'binding_positions.csv',positions)
colors=dict(S='#13aaba',M='#e59b19',L='#2779ef',XL='#922bde');W=1700;H=210+len(positions)*60;left=160;right=1550;x=lambda v:left+(v-700)*(right-left)/550
els=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" rx="22" fill="#f7fbff"/><g font-family="Arial,sans-serif" fill="#173647">','<text x="34" y="40" font-size="27" font-weight="bold">MiCucumber | Current primer binding positions</text>','<text x="34" y="72" font-size="17">AB525437.1 · Extracted 16S rRNA · 1-based, ungapped · Shared linear scale</text>']
for tick in range(700,1251,50):
 xx=x(tick);els.append(f'<line x1="{xx}" x2="{xx}" y1="110" y2="{H-80}" stroke="#deebf3"/><text x="{xx}" y="103" text-anchor="middle" font-size="14">{tick}</text>')
for i,r in enumerate(positions):
 y=145+i*60;c=colors[r['region']];a,b=x(r['F_start']),x(r['F_end']);u,v=x(r['R_start']),x(r['R_end'])
 els.extend([f'<text x="35" y="{y+6}" fill="{c}" font-size="22" font-weight="bold">{r["name"]}</text>',f'<line x1="{a}" x2="{v}" y1="{y}" y2="{y}" stroke="{c}" stroke-opacity=".32" stroke-width="5"/>',f'<path d="M{a},{y-5} H{b-7} V{y-9} L{b},{y} L{b-7},{y+9} V{y+5} H{a} Z" fill="{c}"/>',f'<path d="M{v},{y-5} H{u+7} V{y-9} L{u},{y} L{u+7},{y+9} V{y+5} H{v} Z" fill="{c}"/>',f'<text x="{(a+v)/2}" y="{y-12}" text-anchor="middle" font-size="15" fill="{c}">{r["reference_span_bp"]} bp</text>',f'<text x="{a}" y="{y+24}" text-anchor="middle" font-size="14">F {r["F_start"]}–{r["F_end"]}</text>',f'<text x="{v}" y="{y+24}" text-anchor="middle" font-size="14">R {r["R_start"]}–{r["R_end"]}</text>'])
els.extend([f'<text x="855" y="{H-47}" text-anchor="middle" font-size="17">Position on extracted 16S rRNA (bp)</text>',f'<text x="34" y="{H-18}" font-size="14">Current homologous intervals, including reference mismatches; spans include primers. Product lengths vary among taxa.</text>','</g></svg>']);(out/'binding_positions.svg').write_text(''.join(els))
htmlparts=[]
def colour(q,ch):
 if ch not in 'ACGT':return '#e5e7eb'
 if ch in I[q]:return '#d7edf5'
 if any((n,ch) in [('G','A'),('T','C')] for n in I[q]):return '#e5d6fa'
 return '#ffd3a3'
for reg in ['S','M','L','XL']:
 for chem in ['ordinary','degenerate']:
  pp=[r for r in rr if r['region']==reg and r['chemistry']==chem];elements=[];y=85
  for r in pp:
   for side in ['F','R']:
    q=r[side];m=ol[r[side+'_id']];a,b=m['start'],m['end'];groups=collections.defaultdict(list)
    for item in panel:
     s=seq.get(item['accession'],'')[cols[max(0,a-6)]:cols[b+4]+1].replace('-','')
     if side=='R':s=str(Seq(s).reverse_complement())
     windows=[s[i:i+len(q)] for i in range(len(s)-len(q)+1)]
     def score(t):
      mm=[c not in I[n] for n,c in zip(q,t)];return (not (sum(mm)<=2 and not any(mm[-3:])),sum(mm),sum(mm[-3:]))
     t=min(windows,key=score) if windows else '?'*len(q);groups[item['order'],t].append(item)
    title=f"{r['name']} / {side} | degeneracy {deg(q)} | site {a}–{b}"
    htmlparts.append('<h3>'+html.escape(title)+'</h3><table><tr><th>Primer 5′→3′</th><td>'+''.join(f'<span>{c}</span>' for c in q)+'</td></tr>')
    for (order,t),items in sorted(groups.items()):htmlparts.append('<tr><td>'+html.escape(order+' / '+items[0]['organism']+' / '+items[0]['accession'])+f' ({len(items)})</td><td>'+''.join(f'<span style="background:{colour(n,c)};border-bottom:{"3px solid #173647" if j>=len(q)-3 else "none"}">{c}</span>' for j,(n,c) in enumerate(zip(q,t)))+'</td></tr>')
    htmlparts.append('</table>')
    if chem=='ordinary' and r['option']!=2:continue
    reps=[]
    for order in sorted({k[0] for k in groups}):
     (o,t),items=max([(k,v) for k,v in groups.items() if k[0]==order],key=lambda kv:sum(float(z['weight']) for z in kv[1]));reps.append((order+' / '+items[0]['accession'],t))
    records=[('Primer 5′ → 3′',q)]+reps;elements.append(f'<text x="24" y="{y}" font-size="18">{html.escape(title)}</text>');y+=15
    for label,t in records:
     elements.append(f'<text x="24" y="{y+20}" font-size="13">{html.escape(label)}</text>')
     for i,c in enumerate(t):
      col='#d7edf5' if label.startswith('Primer') else colour(q[i],c);xx=390+22*i;elements.append(f'<rect x="{xx}" y="{y}" width="21" height="28" fill="{col}"/><text x="{xx+6}" y="{y+20}" font-family="monospace" font-size="16">{c}</text>')
     y+=30
    elements.append(f'<rect x="{390+22*(len(q)-3)}" y="{y-30*len(records)}" width="66" height="{30*len(records)}" fill="none" stroke="#173647" stroke-width="2"/>');y+=45
  label=reg+('D' if chem=='degenerate' else '')
  (out/f'base_matching_{label}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="{y}"><rect width="100%" height="100%" rx="18" fill="#f7fafc"/><g font-family="Arial" fill="#173647"><text x="24" y="30" font-size="23">MiCucumber {label} | Primer–template alignment</text><text x="24" y="55" font-size="13">Blue: IUPAC-compatible · Orange: mismatch · Purple: possible G–T · Box: terminal 3 nt · Representative per order</text>'+''.join(elements)+'</g></svg>')
(out/'base_matching.html').write_text('<meta charset="utf-8"><title>MiCucumber base matching</title><style>body{font:16px system-ui;margin:30px;color:#173647}table{border-collapse:collapse}td{padding:3px;border-bottom:1px solid #ddd}td:last-child{white-space:nowrap}span{display:inline-block;width:18px;font:15px monospace;text-align:center;padding:5px 0}</style><h1>MiCucumber：普通与简并引物碱基匹配</h1><p>蓝色为IUPAC相容，橙色为错配，紫色为可能的G–T配对，灰色为不可判定。引物及同向参考均为5′→3′，反向位点已反向互补。LC704718.1未纳入位置比对，其全序列仍用于最终产物评估。</p>'+''.join(htmlparts))
print('position and base-matching figures generated')
