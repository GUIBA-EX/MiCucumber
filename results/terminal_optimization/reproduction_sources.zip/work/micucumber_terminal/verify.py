from common import *
import subprocess
rr=json.loads((p/'selected.json').read_text());control=json.loads((p/'original.json').read_text()) if (p/'original.json').exists() else next(r for r in read(root/'outputs/MiCucumber/sequences/primer_pairs.csv') if r['chemistry']=='original')
(p/'original.json').write_text(json.dumps(control,indent=2));v=p/'verify';v.mkdir(exist_ok=True)
for role in ['target','background']:
 f=v/(role+'.fasta')
 if not f.exists():f.symlink_to((p/(role+'.fasta')).resolve())
(v/'independent_primers.tsv').write_text(''.join(f"{x['name']}\t{x['F']}\t{x['R']}\n" for x in rr)+f"S-original\t{control['F']}\t{control['R']}\n")
subprocess.run([str(root/'work/micucumber_nondegenerate/independent_scan'),str(v)],check=True)
