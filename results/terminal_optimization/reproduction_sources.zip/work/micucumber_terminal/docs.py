from common import *
import zipfile,hashlib
repo=root/'outputs/MiCucumber';dest=repo/'results/terminal_optimization'
(repo/'requirements.txt').write_text('numpy==2.4.6\nbiopython==1.87\nprimer3-py==2.4.0\n')
en='''# Methods

[中文](METHODS.zh-CN.md) · [Reproduction](REPRODUCIBILITY.md)

## Panel and scope

Frozen references contain 1,848 target and 5,600 background records. The common panel has 151 name labels / 351 haplotypes; 145 labels are non-Apodida. Selection weights labels equally, then haplotypes within each label, excluding Apodida and renormalizing. Final whole-sequence results also report all-target metrics. One Apodida accession, LC704718.1, is absent from the alignment: it remains in final full-sequence evaluation but has no alignment-based prediction or plotted bases. Taxonomic names are not synonym-resolved.

## Candidate construction

Reference coordinates use extracted, ungapped AB525437.1 16S. Search forward starts around S 954, M 924, L 843 and XL 774, and reverse starts around 1133: offsets −15 to +25 in steps of two, lengths 18–32 in steps of two. Gap-free observed windows with ≥40% non-Apodida weight contribute their three most frequent sequences and weighted majority consensus. IUPAC alternatives with ≥8% positional support are added greedily at degeneracy caps 4/8/16/32. Previously generated ordinary MiFish-window oligos are also included. All generated candidates passing the oligo structure gate are background-screened; no coverage-only shortlist is used for final selection.

A second bounded search uses up to 12 distinct coordinate combinations among the strongest ordinary pairs per region. Each one-position IUPAC extension adds an observed alternative with ≥1% panel weight. Up to eight neighbor oligos per side are retained by coverage-plus-exact score, together with the ordinary parent, before testing these pair combinations. This includes 3′ positions. It is a finite search, not proof of a global optimum.

## Terminal rules and thermodynamics

3′-terminal degeneracy is allowed. For every concrete IUPAC variant: no terminal homotriplet; at least one G/C among the last three bases; 1–4 G/C among the last five; and no homopolymer longer than four anywhere. The final base need not be fixed or G/C. These project rules follow the same MiUrchin round, informed by [Thermo Fisher guidance](https://www.thermofisher.com/blog/behindthebench/pcr-primer-design-tips/) and [Primer3 parameters](https://primer3.org/manual.html). They are conservative design choices, not experimentally calibrated success thresholds.

Primer3-py 2.4.0: 50 mM monovalent salt, 1.5 mM Mg²⁺ and 0.6 mM dNTP. Expand all variants under 50 nM per variant and 200 nM total per direction divided among variants. Hairpin, homodimer, within-side heterodimer and F/R heterodimer Tm must all be <55°C. F/R Tm-range midpoint differences must be ≤5°C in both scenarios; this is not a bound on every cross-variant Tm difference. Unequal-concentration heterodimers use the larger concentration as an approximation.

Terminal audit additionally reports 5-mer end-stability ΔG at 37°C against the perfect reverse complement, using the stated salts and 200 nM, in kcal/mol across concrete variants. This descriptive calculation has no fitted yield/pass threshold. S-original remains unchanged and is exempt from selection filters.

## Selection and verification

Coverage permits ≤2 mismatches per primer with exact IUPAC compatibility in the last three bases. Exact matching requires zero mismatches in F and R. Both-strand target products are 150–500 bp with ≥50 internal bases; ambiguous binding bases do not establish a hit. Background products require correct orientation and 0–1,000 internal bases. Each selected portfolio permits ≤5 WC≤3 and ≤5 GT≤2 background accessions. WC≤4 is also reported; substantial residual counts remain in several schemes.

For each region, select one degenerate pair, one ordinary pair and an ordinary two-pair comparator. Rank by non-Apodida coverage + exact matching with equal weight, then coverage, exact matching, lower total degeneracy and fewer background accessions. Cross-pair multiplex interactions are not asserted because the two-pair metric is a separate-PCR union. XL A/B is retained only for comparison: it adds no common-panel coverage or exact matching over XL single.

An independent C++ all-window scanner re-evaluates the selected full products without the background prefilter. All 11,200 alignment-based target-state checks and 32 background-accession-set checks agree. The absent Apodida alignment record is excluded from prediction comparisons but not from final evaluation. Wet-lab and independent-holdout validation remain pending.

## Figures and interpretation

Reference intervals are drawn on one linear axis; interval lengths and oriented reference bases are checked against selected oligos. Representative SD/MD/LD/XLD spans are 223/247/310/394 bp. These are reference intervals, not universal product sizes or guaranteed amplification of every reference variant. Base-matching figures show actual 5′→3′ bases, not heatmaps.

Ordinary S/M/L improve over the preceding release, but strict removal of homopolymers reduces degenerate exact matching and XL coverage. Published before/after tables retain these losses. Background counts are accession counts, not experimental read fractions. Design context: [Miya et al. 2015](https://doi.org/10.1098/rsos.150088).
'''
zh='''# 方法

[English](METHODS.md) · [复现](REPRODUCIBILITY.zh-CN.md)

## 面板与范围

冻结参考包含1,848条目标及5,600条背景记录。共同面板为151个分类名称标签、351个单倍型，非Apodida为145个标签。选择时标签等权、标签内单倍型等权，排除Apodida后重新归一化；完整序列扫描另报告全部目标指标。LC704718.1（Apodida）不在位置比对中，仍参与最终完整序列评估，但不作为比对预测复核或碱基图的有效行。名称未做同物异名校正。

## 候选构建

使用AB525437.1提取、去缺口的16S坐标。正向起点分别围绕S 954、M 924、L 843、XL 774，反向起点围绕1133：偏移−15至+25、步长2；长度18–32、步长2。非Apodida权重至少40%的无缺口窗口用于提取前三种常见真实序列和加权多数共识。逐位点支持≥8%的替代碱基按频率加入IUPAC，在4/8/16/32重简并上限处保留候选。另纳入既有MiFish邻近窗口普通候选。最终对全部通过单引物结构门槛的候选做背景扫描，不按覆盖率提前缩减候选池。

第二轮从每个长度表现较好的普通配对中选最多12种不同坐标组合。对单个位点加入面板权重≥1%的实际观察替代碱基，包括3′端位置；每侧按覆盖与完全匹配之和保留最多8个邻近简并候选，加普通亲本后测试组合。这是有限搜索，不证明全局最优。

## 末端与热力学规则

**允许3′末端简并。** 每个实际IUPAC变体须满足：末端无三连同碱基；末端3位至少含1个G/C；末端5位含1–4个G/C；全序列连续同碱基不超过4。最后一位不强制固定，也不强制为G/C。沿用MiUrchin本轮规则，参考[Thermo Fisher](https://www.thermofisher.com/blog/behindthebench/pcr-primer-design-tips/)与[Primer3](https://primer3.org/manual.html)；这些是项目采用的保守设计条件，并非实验标定的成功阈值。

Primer3-py 2.4.0条件：单价盐50 mM、Mg²⁺ 1.5 mM、dNTP 0.6 mM。展开全部变体，分别按每变体50 nM、每方向总量200 nM均分评估。发卡、同源二聚体、同侧异源二聚体、F/R异源二聚体Tm均须<55°C；两种情景下F/R的Tm范围中点差均须≤5°C，不代表任意两个具体变体的Tm差均≤5°C。浓度不等的二聚体使用较大浓度近似。

末端审计另列末端5 nt与完全反向互补序列在37°C、上述盐条件、200 nM下的ΔG范围，单位kcal/mol，作描述性比较，不设经过产量标定的阈值。S-original保持原序列，不参与候选筛选规则。

## 选择与独立复核

覆盖允许每条引物≤2处错配、末端3位IUPAC完全相容；完全匹配要求F/R均零错配。目标双链扫描要求产物150–500 bp、内部≥50 nt；不把结合位点模糊碱基计为确认命中。背景要求方向正确、内部0–1,000 nt；每套组合WC≤3与GT≤2各允许最多5条背景accession，另列WC≤4敏感性结果，部分方案在该模型下仍有明显背景风险。

每个长度保留简并单对、普通单对、普通两对比较。先最大化非Apodida覆盖率与完全匹配率等权和，再依次按覆盖、完全匹配、较低总简并度、较少背景命中排序。两对采用独立PCR并集，不声称已验证跨配对混池相互作用。XL两对未提高共同面板覆盖或完全匹配，仅保留为比较，不据此增加PCR对数。

独立C++全窗口扫描不使用背景预筛选，重算完整配对产物：11,200项比对预测状态及32项背景accession集合检查全部一致。缺少比对的Apodida记录不计入预测比较，但保留在最终全序列评估。尚无湿实验与独立留出集验证。

## 图件与解释

当前结合区间按同一线性轴绘制，逐条检查区间长度、引物长度及定向参考碱基。SD/MD/LD/XLD参考跨度为223/247/310/394 bp，不是所有类群的固定产物长度，也不代表每个参考变体必然扩增。碱基图显示实际5′→3′序列，不用热图替代。

普通S/M/L较上一版改善，但去掉长串同碱基后简并完全匹配率与XL覆盖下降，修正前后表保留这些损失。背景数字是accession数，不是实验reads比例。设计参考：[Miya等，2015](https://doi.org/10.1098/rsos.150088)。
'''
(repo/'docs/METHODS.md').write_text(en);(repo/'docs/METHODS.zh-CN.md').write_text(zh)
old={r['scheme']:r for r in read(dest/'previous_comparison.csv') if r['panel']=='common'};comp=read(dest/'comparison.csv');lines=['# Terminal correction / 末端修正','','## Material Passport','','Verification status: VERIFIED for frozen computational data; wet-lab validation pending. / 冻结数据计算复核通过，实验验证待完成。','','Scope: bounded primer search, independent product scans, terminal rules and coordinate verification. No population-wide sensitivity/specificity or hypothesis-test claim is made from this reused design panel. / 范围为有限候选搜索、独立产物扫描、末端规则及坐标复核，不从重复使用的设计面板推断总体灵敏度、特异性或假设检验结果。','','3′-terminal degeneracy is permitted; actual variants must satisfy the same MiUrchin terminal constraints. / 允许3′末端简并，实际变体须符合与MiUrchin一致的末端约束。','','| Portfolio | Previous coverage / exact | Current coverage / exact |','|---|---:|---:|']
for r in comp:
 b=old['MiCucumber-S-original' if r['scheme']=='S-original' else r['scheme']];lines.append(f"| {r['scheme']} | {float(b['non_Apodida_coverage_pct']):.2f}% / {float(b['non_Apodida_exact_pct']):.2f}% | {float(r['coverage_pct']):.2f}% / {float(r['exact_pct']):.2f}% |")
lines+=['','Ordinary S/M/L improve, but the strict-terminal constraints reduce several degenerate metrics. In particular SD exact matching falls from 27.48% to 3.28%; XL two-pair coverage and exact matching are unchanged from its new single pair. This is not a uniform upgrade. / 普通S/M/L改善，但多项简并指标下降；SD完全匹配从27.48%降至3.28%，XL两对不优于本轮单对，因此不称为全面升级。','','All 32 selected oligos pass across concrete variants. S-original is unchanged and exempt. Target-state checks: 11,200 with zero differences; background-set checks: 32 with zero differences. LC704718.1 is missing from the alignment only and remains in full-sequence reporting. / 32条入选引物的实际变体全部通过规则，原始对照保持不变且豁免筛选。目标状态11,200项、背景集合32项，均无差异。LC704718.1仅缺位置比对，完整序列结果仍保留。','','WC≤4 counts remain substantial (e.g. LD 1,157, XLD 1,357); WC≤3/GT≤2 acceptance does not establish experimental specificity. / WC≤4仍有明显命中（如LD 1,157、XLD 1,357）；通过WC≤3/GT≤2不能证明实验特异性。','','[Terminal audit](../results/terminal_optimization/terminal_audit.csv) · [Thermodynamics](../results/terminal_optimization/thermal.csv) · [Verification](../results/terminal_optimization/verification.json) · [Missed references](../results/terminal_optimization/missed_references.csv) · [Coordinates](../results/current/binding_positions.csv)']
(repo/'docs/TERMINAL_VALIDATION.md').write_text('\n'.join(lines)+'\n')
for iszh in [False,True]:
 f=repo/('docs/REPRODUCIBILITY.zh-CN.md' if iszh else 'docs/REPRODUCIBILITY.md');f.write_text('''# Reproduction / 复现

Install Python 3.12 dependencies from `requirements.txt`, then extract [the current source bundle](../results/terminal_optimization/reproduction_sources.zip) into a fresh directory. / 安装依赖并将当前源码包解压到新目录。

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python work/micucumber_terminal/choose.py
mkdir -p work/micucumber_nondegenerate
c++ -O3 -std=c++17 work/micucumber_nondegenerate/independent_scan.cpp -o work/micucumber_nondegenerate/independent_scan
python work/micucumber_terminal/verify.py
python work/micucumber_terminal/summarize.py
python work/micucumber_terminal/end_audit.py
python work/micucumber_terminal/figures.py
```

Outputs: `work/micucumber_terminal/release/`. This route repeats selection from frozen feasible states, full-product verification, terminal audit and figures without new database retrieval. It requires installed dependencies and a C++17 compiler. / 从冻结可行候选状态重算选择、全产物复核、末端审计和图件，不重新下载数据库。

For upstream discovery, the bundle also includes `discover.py`, `scan_sites.cpp`, `optimize.py`, `neighbors.py` and `merge_neighbors.py`. Run discovery, compile the site scanner, scan `work/micucumber_terminal/sites`, run `optimize.py`, build neighbors, scan `neighbor_sites`, merge neighbors, then execute the commands above. The site scanner writes all candidate background sites; these intermediate files can be large. / 源码包也包含完整上游候选搜索及背景扫描代码；按上述顺序重算，中间背景位点文件较大。

```sh
python scripts/check_release.py
```

The release checker uses the standard library to verify exported sequences, all concrete-variant terminal rules, both concentration scenarios, recomputed panel/background metrics, original-control invariance, reference coordinates, local links, bundle integrity and SHA-256 hashes. / 发布检查器使用标准库验证序列、末端规则、双浓度热力学、指标、原始对照不变性、坐标、链接、压缩包与哈希。

Earlier workflows in `scripts/reproduce.py` and `reproducibility/frozen/` describe the retained pre-terminal analysis; they are not the current design entry point. / 早期脚本和冻结包为保留分析，不是本轮设计入口。
''')
for iszh in [False,True]:
 f=repo/('docs/FILES.zh-CN.md' if iszh else 'docs/FILES.md');f.write_text('''# File index / 文件索引

| File | Contents / 内容 |
|---|---|
| [Primer pairs](../sequences/primer_pairs.csv) | Current 13 portfolios / 17 paired rows |
| [FASTA](../sequences/primers.fasta) | Current 34 oligos, including original control |
| [Comparison](../results/current/comparison.csv) | Non-Apodida and all-target metrics |
| [Coordinates](../results/current/binding_positions.csv) | Current intervals and oriented reference bases |
| [Terminal analysis](../results/terminal_optimization/) | Current evidence, previous comparison, thermodynamics and reproduction bundle |
| [Base matching](../results/terminal_optimization/base_matching.html) | Actual bases for all current candidates |
| [Position map](../figures/binding_positions.svg) | Shared linear reference coordinate axis |
| [Report](../report.html) | Bilingual browser overview |
| [Validation](TERMINAL_VALIDATION.md) | Trade-offs and independent checks |
| [Reproduction](REPRODUCIBILITY.md) | Current rerun instructions |
| [Original control](../sequences/MiCucumber-S-original.fasta) | Unchanged S-original |
| [Frozen earlier data](../reproducibility/frozen/) | Earlier analysis inputs |
| [Copyright](../COPYRIGHT.md) | Rights and reuse terms |

`results/degenerate/`, `results/nondegenerate/`, `results/matching/` and `results/mifish_trial/` retain earlier analysis evidence. Current sequence and performance entry points are the files above. / 这些目录保留早期证据，当前序列与性能以本表入口为准。
''')
 f=repo/('docs/NAMING.zh-CN.md' if iszh else 'docs/NAMING.md');f.write_text('''# Names / 命名

S, M, L and XL identify homologous design regions. D marks a degenerate single pair; the ordinary single pair has no suffix, and A/B identify the two ordinary components. / S、M、L、XL为同源设计区域；D标记简并单对，普通单对不加后缀，A/B为普通两对的组件。

| Region | Degenerate | Ordinary | Ordinary A/B |
|---|---|---|---|
| S | SD | S | SA / SB |
| M | MD | M | MA / MB |
| L | LD | L | LA / LB |
| XL | XLD | XL | XLA / XLB |

S-original is the unchanged original control. A+B metrics mean separate-PCR unions. 3′-terminal degeneracy is allowed; it does not require a separate name. / S-original为不变的原始对照；A+B表示独立PCR并集。允许3′端简并，不额外增加命名类型。

[Current sequences](../sequences/primer_pairs.csv) · [Methods](METHODS.md)
''')
export=read(repo/'sequences/primer_pairs.csv');write(repo/'docs/name_mapping.csv',[dict(pair_name=r['pair_name'],pair_id=r['pair_id'],F_sha256=hashlib.sha256(r['F'].encode()).hexdigest(),R_sha256=hashlib.sha256(r['R'].encode()).hexdigest()) for r in export])
(repo/'figures/overview_design.md').write_text('''# MiCucumber overview

The watercolor banner follows the established MiCucumber illustration. Badge values are current SD/MD/LD/XLD reference spans: 223, 247, 310, 394 bp. Scientific coordinates are generated separately by `figures.py` as `binding_positions.svg` from selected intervals, on one linear scale. Full reference bases and mismatch counts are in `results/current/binding_positions.csv`. Animal drawings are schematic.
''')
f=repo/'CHANGELOG.md';f.write_text('# Terminal-constrained comparison\n\n- Allow 3′-terminal IUPAC degeneracy, testing every actual variant.\n- Apply the MiUrchin terminal and two-concentration thermodynamic rules.\n- Independently verify 11,200 target states and 32 background accession sets.\n- Publish all current sequences, actual-coordinate and base-matching diagrams, bilingual documentation and reproduction sources.\n- Explicitly retain losses in degenerate exact matching, low XL coverage and relaxed-model background risks.\n\n'+f.read_text())
# Frozen candidate states make selection/revalidation reproducible without repeating the larger upstream scan.
files=[p/n for n in ['common.py','discover.py','optimize.py','neighbors.py','merge_neighbors.py','choose.py','verify.py','summarize.py','end_audit.py','figures.py','scan_sites.cpp','combined_feasible.json','combined_oligos.json','panel.csv','previous_pairs.csv','original.json','selected.json','audit.json','target.fasta','background.fasta','target_aligned.fasta']]
files += [root/'work/micucumber_nondegenerate/independent_scan.cpp',root/'work/micucumber_mifish/specific/oligos.csv',repo/'requirements.txt']
with zipfile.ZipFile(dest/'reproduction_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.relative_to(root))
print('documents and reproduction bundle updated')
