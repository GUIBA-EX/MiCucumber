from common import *
import collections
rev={frozenset(v):k for k,v in I.items() if k!='X'}
rows=json.loads((p/'oligos.json').read_text());old={r['id']:r for r in rows};seq={r.id:str(r.seq).upper() for r in SeqIO.parse(p/'target_aligned.fasta','fasta')};cols=[i for i,b in enumerate(seq['AB525437.1']) if b!='-'];feasible=json.loads((p/'feasible.json').read_text());pairs=[];new=[];seen={(r['region'],r['side'],r['start'],r['end'],r['sequence']):r['id'] for r in rows}
# Small IUPAC supersets of high-scoring ordinary pairs, with observed alternatives.
for reg in ['S','M','L','XL']:
 candidates=sorted([r for r in feasible if r['region']==reg and r['degeneracy_F']*r['degeneracy_R']==1],key=lambda r:r['coverage']+r['exact'],reverse=True)
 # Keep up to 12 distinct F/R coordinate combinations rather than near-duplicate sequence states.
 seeds=[];coords=set()
 for r in candidates:
  k=tuple((old[r[s+'_id']]['start'],old[r[s+'_id']]['end']) for s in ['F','R'])
  if k not in coords:coords.add(k);seeds.append(r)
  if len(seeds)>=12:break
 for pair in seeds:
  variants={}
  for side in ['F','R']:
   r=old[pair[side+'_id']];a,b=r['start'],r['end'];q=r['sequence'];freq=[collections.Counter() for _ in q]
   for x,weight in zip(panel,w):
    s=seq.get(x['accession'],'')[cols[a-1]:cols[b-1]+1]
    if side=='R':s=str(Seq(s).reverse_complement())
    if len(s)!=len(q) or not set(s)<=set('ACGT'):continue
    for j,c in enumerate(s):freq[j][c]+=weight
   qs=[]
   for j,ct in enumerate(freq):
    for c,v in ct.items():
     if c in I[q[j]] or v<.01:continue
     qq=q[:j]+rev[frozenset(I[q[j]]+c)]+q[j+1:]
     if terminal(qq):qs.append(qq)
   pool=[]
   for qq in qs:
    key=(reg,side,a,b,qq)
    if key in seen:n=seen[key];obj=old[n]
    else:
     cv=[];ex=[]
     for x in panel:
      s=seq.get(x['accession'],'')[cols[max(0,a-6)]:cols[b+4]+1].replace('-','')
      if side=='R':s=str(Seq(s).reverse_complement())
      hh=[]
      for i in range(len(s)-len(qq)+1):
       t=s[i:i+len(qq)]
       if not set(t)<=set('ACGT'):continue
       mm=[c not in I[n] for n,c in zip(qq,t)];hh.append((sum(mm),sum(mm[-3:])))
      cv.append(any(n<=2 and z==0 for n,z in hh));ex.append(any(n==0 for n,z in hh))
     obj=dict(r,id=f'N{len(new):05d}',sequence=qq,degeneracy=deg(qq),cv=cv,ex=ex,coverage=float(w@cv),exact=float(w@ex))
     if any(t[2]>=55 for t in oligo_thermal(qq)):continue
     n=obj['id'];new.append(obj);old[n]=obj;seen[key]=n
    pool.append(obj)
   # Top 8 neighbors per side, plus the ordinary parent.
   variants[side]=[r]+sorted(pool,key=lambda x:(x['coverage']+x['exact'],x['coverage']),reverse=True)[:8]
  for f,r in itertools.product(variants['F'],variants['R']):
   if f['degeneracy']*r['degeneracy']==1:continue
   pairs.append(dict(region=reg,F_id=f['id'],R_id=r['id']))
(p/'neighbor_pairs.json').write_text(json.dumps(pairs));(p/'neighbor_oligos.json').write_text(json.dumps(new));used={r[s+'_id'] for r in pairs for s in ['F','R']};d=p/'neighbor_sites';d.mkdir(exist_ok=True);(d/'oligos.tsv').write_text(''.join(f"{n} {old[n]['side']} {old[n]['sequence']}\n" for n in sorted(used)));print('neighbors',len(new),'used oligos',len(used),'pairs',len(pairs),flush=True)
