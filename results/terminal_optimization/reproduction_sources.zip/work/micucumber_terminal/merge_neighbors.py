from common import *
import collections
ol={x['id']:x for x in json.loads((p/'oligos.json').read_text())+json.loads((p/'neighbor_oligos.json').read_text())};h=collections.defaultdict(lambda:collections.defaultdict(list))
for n,a,o,g,pos,mm,last in csv.reader((p/'neighbor_sites/background_sites.tsv').open(),delimiter='\t'):
 if g=='0' and int(mm)>3:continue
 h[n,int(g)][a,o].append((int(pos),int(mm)))
rows=[]
for r in json.loads((p/'neighbor_pairs.json').read_text()):
 f,re=ol[r['F_id']],ol[r['R_id']];ft,rt=oligo_thermal(f['sequence']),oligo_thermal(re['sequence'])
 if any(abs((a[0]+a[1]-b[0]-b[1])/2)>5 for a,b in zip(ft,rt)):continue
 cv=(np.array(f['cv'])&re['cv']).tolist();ex=(np.array(f['ex'])&re['ex']).tolist()
 q=dict(r,F=f['sequence'],R=re['sequence'],degeneracy_F=f['degeneracy'],degeneracy_R=re['degeneracy'],cv=cv,ex=ex,coverage=float(w@cv),exact=float(w@ex))
 for gt,col,limit in [(0,'WC3',3),(1,'GT2',2)]:
  a=h[f['id'],gt];b=h[re['id'],gt];found=set()
  for key in a.keys()&b.keys():
   if any(fm<=limit and rm<=limit and 0<=rp-fp-len(f['sequence'])<=1000 for fp,fm in a[key] for rp,rm in b[key]):found.add(key[0])
   if len(found)>5:break
  q[col]=sorted(found)
 if len(q['WC3'])<=5 and len(q['GT2'])<=5:rows.append(q)
base=json.loads((p/'feasible.json').read_text());(p/'combined_feasible.json').write_text(json.dumps(base+rows));(p/'combined_oligos.json').write_text(json.dumps(list(ol.values())));print('additional feasible',len(rows))
