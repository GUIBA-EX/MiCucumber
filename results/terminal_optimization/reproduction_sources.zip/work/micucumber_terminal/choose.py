from common import *
feasible=json.loads((p/'combined_feasible.json').read_text())
selected=[];audit=[]
for reg in ['S','M','L','XL']:
 for chem,count in [('degenerate',1),('ordinary',1),('ordinary',2)]:
  pool=[r for r in feasible if r['region']==reg and (r['degeneracy_F']*r['degeneracy_R']>1)==(chem=='degenerate')]
  # Include a terminal/thermal signature in state reduction, so a failing representative does not hide alternatives.
  dedup={}
  for r in pool:
   key=(tuple(r['cv']),tuple(r['ex']),tuple(r['WC3']),tuple(r['GT2']),r['F'],r['R'])
   dedup.setdefault(key,r)
  pool=list(dedup.values());rejections=0
  while True:
   if not pool:raise RuntimeError((reg,chem,count,'no eligible candidates'))
   best=None;chosen=None
   def combos():
    if count==1:
     yield from itertools.combinations(pool,1);return
    cm=np.array([r['cv'] for r in pool]);em=np.array([r['ex'] for r in pool])
    for i in range(len(pool)-1):
     score=(cm[i+1:]|cm[i])@w+(em[i+1:]|em[i])@w
     for j in np.flatnonzero(score>=(-1 if best is None else best[0]-1e-10)):yield pool[i],pool[i+1+int(j)]
   for pp in combos():
    a=set().union(*(set(x['WC3']) for x in pp));b=set().union(*(set(x['GT2']) for x in pp))
    if len(a)>5 or len(b)>5:continue
    c=float(w@np.logical_or.reduce([x['cv'] for x in pp]));e=float(w@np.logical_or.reduce([x['ex'] for x in pp]));score=(round(c+e,12),round(c,12),round(e,12),-sum(x['degeneracy_F']+x['degeneracy_R'] for x in pp),-len(a)-len(b))
    if best is None or score>best:best=score;chosen=pp
   if chosen is None:raise RuntimeError((reg,chem,count,'no portfolio'))
   bad=[r for r in chosen if not thermal(r['F'],r['R'])[0]]
   if not bad:break
   rejections+=len(bad);pool=[r for r in pool if all((r['F'],r['R'])!=(b['F'],b['R']) for b in bad)]
  scheme=reg+'D' if chem=='degenerate' else reg if count==1 else reg+'A+'+reg+'B'
  for i,r in enumerate(chosen):selected.append(dict(r,scheme=scheme,name=reg+'D' if chem=='degenerate' else reg if count==1 else reg+chr(65+i),chemistry=chem,option=count,union_coverage=best[1],union_exact=best[2],thermal=thermal(r['F'],r['R'])[1]))
  audit.append(dict(scheme=scheme,eligible=len(pool),thermal_rejections=rejections,coverage=best[1],exact=best[2]));print(audit[-1],flush=True)
(p/'selected.json').write_text(json.dumps(selected,indent=2));(p/'audit.json').write_text(json.dumps(audit,indent=2));print('DONE',flush=True)
