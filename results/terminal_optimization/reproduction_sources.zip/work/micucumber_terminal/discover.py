from common import *
import collections
from Bio.Data.IUPACData import ambiguous_dna_values
rev={frozenset(v):k for k,v in I.items() if k!='X'}
seq={r.id:str(r.seq).upper() for r in SeqIO.parse(p/'target_aligned.fasta','fasta')};ref=seq['AB525437.1'];cols=[i for i,b in enumerate(ref) if b!='-'];rows=[];seen=set()
# Candidate generation is weighted by the same non-Apodida panel as selection.
def add(reg,side,a,b,q):
 key=(reg,side,a,b,q)
 if key in seen or not terminal(q):return
 seen.add(key)
 windows=[]
 for x in panel:
  s=seq.get(x['accession'],'')[cols[max(0,a-6)]:cols[b+4]+1].replace('-','')
  if side=='R':s=str(Seq(s).reverse_complement())
  windows.append(s)
 cv=[];ex=[]
 for s in windows:
  hits=[]
  for i in range(len(s)-len(q)+1):
   t=s[i:i+len(q)]
   if not set(t)<=set('ACGT'):continue
   mm=[c not in I[n] for n,c in zip(q,t)];hits.append((sum(mm),sum(mm[-3:])))
  cv.append(any(n<=2 and z==0 for n,z in hits));ex.append(any(n==0 for n,z in hits))
 cov=float(w@cv)
 if cov<.1:return
 rows.append(dict(id=f'C{len(rows):05d}',region=reg,side=side,sequence=q,start=a,end=b,degeneracy=deg(q),cv=cv,ex=ex,coverage=cov,exact=float(w@ex)))
for reg,anchor in [('S',954),('M',924),('L',843),('XL',774)]:
 for side,base in [('F',anchor),('R',1133)]:
  for a in range(base-15,base+26,2):
   for length in range(18,33,2):
    b=a+length-1;windows=[seq.get(x['accession'],'')[cols[a-1]:cols[b-1]+1] for x in panel]
    if side=='R':windows=[str(Seq(s).reverse_complement()) for s in windows]
    valid=[i for i,s in enumerate(windows) if len(s)==length and set(s)<=set('ACGT')]
    if sum(w[i] for i in valid)<.4:continue
    freq=collections.Counter()
    for i in valid:freq[windows[i]]+=w[i]
    for q,_ in freq.most_common(3):add(reg,side,a,b,q)
    counts=[collections.Counter() for _ in range(length)]
    for i in valid:
     for j,c in enumerate(windows[i]):counts[j][c]+=w[i]
    majority=''.join(c.most_common(1)[0][0] for c in counts);add(reg,side,a,b,majority)
    # Add supported alternatives greedily, retaining stages at degeneracy caps.
    alternatives=sorted([(weight/sum(counts[j].values()),j,c) for j,ct in enumerate(counts) for c,weight in ct.items() if c!=majority[j]],reverse=True)
    for cap in [4,8,16,32]:
     sets=[set(c) for c in majority]
     for fraction,j,c in alternatives:
      if fraction<.08:continue
      candidate=[v|{c} if k==j else v for k,v in enumerate(sets)]
      if math.prod(map(len,candidate))>cap:continue
      q=''.join(rev[frozenset(v)] for v in candidate)
      if not terminal(q):continue
      sets=candidate
     q=''.join(rev[frozenset(v)] for v in sets);add(reg,side,a,b,q)
  print(reg,side,'generated',len(rows),flush=True)
# Include all previously generated ordinary shifted-window candidates.
for r in read(root/'work/micucumber_mifish/specific/oligos.csv'):add(r['region'],r['side'],int(r['start']),int(r['end']),r['sequence'])
(p/'all_oligos.json').write_text(json.dumps(rows))
# Screen the entire generated pool, avoiding coverage-only pruning before specificity.
rows=[r for r in rows if all(t[2]<55 for t in oligo_thermal(r['sequence']))]
(p/'oligos.json').write_text(json.dumps(rows));d=p/'sites';d.mkdir(exist_ok=True);(d/'oligos.tsv').write_text(''.join(f"{r['id']} {r['side']} {r['sequence']}\n" for r in rows));print('screened oligos',len(rows),flush=True)
