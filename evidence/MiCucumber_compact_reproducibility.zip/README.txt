Python 3.12 + numpy. Run: python work/micucumber_compact/optimize.py
Recomputes exhaustive subset selection and detection tables from frozen, previously validated per-pair hit evidence. Does not rerun original sequence scanning or wet-lab tests. See report.html for scope and assumptions.
