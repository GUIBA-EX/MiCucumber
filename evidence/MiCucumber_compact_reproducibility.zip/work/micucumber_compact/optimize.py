from pathlib import Path
import csv,json,itertools,collections,hashlib
import numpy as np
root=Path(__file__).resolve().parents[2];p=root/'work/micucumber_round2/optimization';out=root/'outputs/MiCucumber_compact'
pairs=json.loads((p/'shortlist_fast.json').read_text());tax={r['accession']:r for r in csv.DictReader((p/'target_taxonomy.tsv').open(),delimiter='\t')};meta={r['accession']:r for r in csv.DictReader((p/'metadata.tsv').open(),delimiter='\t')};tab=collections.defaultdict(dict);hits=collections.defaultdict(dict)
for r in csv.DictReader((p/'target_detail.tsv').open(),delimiter='\t'):tab[r['name'],r['panel']][r['accession']]=r
for r in csv.DictReader((p/'independent_hits.tsv').open(),delimiter='\t'):hits[r['name'],r['role'],r['model']][r['accession']]=r
rows=[];schemes=[];excluded=set(json.loads((out/'thermal_exclusions.json').read_text())) if (out/'thermal_exclusions.json').exists() else set()
for locus in ['MiCucumber-v4opt','MiCucumber-S','MiCucumber-M','MiCucumber-L']:
 cand=[r for r in pairs if r['group']==locus and r['name'] not in excluded];names=[r['name'] for r in cand];ids=sorted(set(tab[names[0],'common'])|set(tab[names[0],'own_region']));nonapo=np.array([tax[k]['order']!='Apodida' for k in ids]);weights={pn:np.array([float(tab[names[0],pn].get(k,{}).get('weight',0)) for k in ids]) for pn in ['common','own_region']};nw={pn:w*nonapo/(w*nonapo).sum() for pn,w in weights.items()};cw=np.array([[hits[n,'target','WC'].get(k,{}).get('le2last3')=='1' for k in ids] for n in names]);ew=np.array([[hits[n,'target','WC'].get(k,{}).get('exact')=='1' for k in ids] for n in names]);bg={m:[{k for k,r in hits[n,'background',m].items() if r[metric]=='1'} for n in names] for m,metric in [('WC','le3'),('GT','le2')]}
 for count in [1,2,3,4]:
  evaluated=[]
  for comb in itertools.combinations(range(len(cand)),count):
   wc=set().union(*(bg['WC'][i] for i in comb));gt=set().union(*(bg['GT'][i] for i in comb))
   if max(len(wc),len(gt))>20:continue
   cov=cw[list(comb)].any(0);ex=ew[list(comb)].any(0);cc=float(nw['common'][cov].sum());co=float(nw['own_region'][cov].sum());ec=float(nw['common'][ex].sum());eo=float(nw['own_region'][ex].sum());evaluated.append((comb,cc,co,ec,eo,len(wc),len(gt)))
  for budget in [5,20]:
   feasible=[r for r in evaluated if max(r[5:])<=budget]
   if not feasible:continue
   anchor=max(feasible,key=lambda r:((r[1]+r[2])/2,(r[3]+r[4])/2,-r[5]-r[6]))
   for tolerance in [0,1,2]:
    rr=[r for r in feasible if r[1]>=anchor[1]-tolerance/100-1e-10 and r[2]>=anchor[2]-tolerance/100-1e-10]
    best=max(rr,key=lambda r:((r[3]+r[4])/2,(r[1]+r[2])/2,-r[5]-r[6]));comb=best[0];chosen=[names[i] for i in comb];sid=f'{locus}_N{count}_B{budget}_T{tolerance}';scheme=dict(name=sid,locus=locus,count=count,budget=budget,tolerance_pp=tolerance,pair_names=chosen,enumerated_combinations=len(feasible));schemes.append(scheme)
    cov=cw[list(comb)].any(0);ex=ew[list(comb)].any(0)
    for pn,w in weights.items():
     eligible=[k for k,v in zip(ids,w) if v];apo=w*(~nonapo);row=dict(scheme=sid,locus=locus,count=count,budget=budget,tolerance_pp=tolerance,panel=pn,n_labels=len({tax[k]['organism'] for k in eligible}),n_haplotypes=len(eligible),non_Apodida_labels=len({tax[k]['organism'] for k in eligible if tax[k]['order']!='Apodida'}),coverage_pct=100*float(w[cov].sum()),exact_pct=100*float(w[ex].sum()),non_Apodida_coverage_pct=100*float(nw[pn][cov].sum()),non_Apodida_exact_pct=100*float(nw[pn][ex].sum()),Apodida_coverage_pct=100*float(apo[cov].sum()/apo.sum()),Apodida_exact_pct=100*float(apo[ex].sum()/apo.sum()))
     for model,metrics in [('WC',['le2','le3','le4','ambiguous']),('GT',['le2','ambiguous'])]:
      for metric in metrics:row[model+'_'+metric]=len({k for n in chosen for k,r in hits[n,'background',model].items() if r[metric]=='1'})
     row['pair_ids']=';'.join(chosen);rows.append(row)
  print(locus,count,'enumerated',len(evaluated),flush=True)
# Primary comparison: <=5 background hits/model and <=1 pp loss from coverage-first anchor at same pair count.
primary=[s for s in schemes if s['budget']==5 and (s['tolerance_pp']==1 or (s['locus']=='MiCucumber-v4opt' and s['count']==2 and s['tolerance_pp']==2))];primarynames={s['name'] for s in primary};seqrows=[];missing=[];orderrows=[];bgrows=[];checks=0
for s in primary:
 for i,n in enumerate(s['pair_names'],1):
  r=next(r for r in pairs if r['name']==n);seqrows.append(dict(scheme=s['name'],locus=s['locus'],reaction=i,pair_id=n,F=r['F'],R=r['R']))
 for pn in ['common','own_region']:
  rr=tab[s['pair_names'][0],pn];groups=collections.defaultdict(list)
  for k,r in rr.items():
   for n in s['pair_names']:
    for metric in ['exact','le2last3']:
     assert (tab[n,pn][k][metric]=='True')==(hits[n,'target','WC'].get(k,{}).get(metric)=='1');checks+=1
   d=dict(accession=k,organism=r['organism'],order=tax[k]['order'],weight=float(r['weight']),cov=any(tab[n,pn][k]['le2last3']=='True' for n in s['pair_names']),exact=any(tab[n,pn][k]['exact']=='True' for n in s['pair_names']));groups[d['organism']].append(d)
  for label,sub in groups.items():
   n=sum(d['cov'] for d in sub);missing.append(dict(scheme=s['name'],locus=s['locus'],count=s['count'],panel=pn,organism=label,source_order=sub[0]['order'],haplotypes=len(sub),detected_haplotypes=n,exact_haplotypes=sum(d['exact'] for d in sub),status='fully_missed' if n==0 else 'partially_missed' if n<len(sub) else 'covered'))
  byorder=collections.defaultdict(list)
  for sub in groups.values():byorder[sub[0]['order']].extend(sub)
  for order,sub in byorder.items():
   den=sum(d['weight'] for d in sub);orderrows.append(dict(scheme=s['name'],locus=s['locus'],count=s['count'],panel=pn,source_order=order,n_labels=len({d['organism'] for d in sub}),coverage_pct=100*sum(d['weight'] for d in sub if d['cov'])/den,exact_pct=100*sum(d['weight'] for d in sub if d['exact'])/den))
 for model,metric in [('WC','le3'),('WC','le4'),('GT','le2')]:
  for k in sorted({k for n in s['pair_names'] for k,r in hits[n,'background',model].items() if r[metric]=='1'}):bgrows.append(dict(scheme=s['name'],model=model,criterion=metric,accession=k,organism=meta[k]['organism'],clade=meta[k]['clade']))
def write(fn,data):
 with (out/fn).open('w') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
write('all_tradeoffs.csv',rows);write('primary_comparison.csv',[r for r in rows if r['scheme'] in primarynames]);write('primer_pairs.csv',seqrows);write('taxon_detection.csv',missing);write('missed_taxa.csv',[r for r in missing if r['status']!='covered']);write('order_coverage.csv',orderrows);write('offtargets.csv',bgrows)
(out/'schemes.json').write_text(json.dumps(schemes,indent=2));(out/'validation.json').write_text(json.dumps(dict(status='PASS',comparisons=checks,method='exhaustive subset enumeration of 96 previously whole-sequence-validated candidate pairs, separately by locus; no new sequences; individual pair detection checked against independent C++ outcomes',optimization='exclude Apodida from objective only; equal common/own-region non-Apodida weighted coverage first; maximize exact within 0/1/2 pp of that anchor on each panel; WC3 and GT2 unions <=5/20; primary <=5 and tolerance1',source_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [p/'target_detail.tsv',p/'independent_hits.tsv',p/'shortlist_fast.json',p/'target_taxonomy.tsv']},scope='separate PCRs; conditional optimum within verified candidate pool; no global design optimum; no wet-lab validation'),indent=2))
