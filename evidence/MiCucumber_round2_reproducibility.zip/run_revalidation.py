from pathlib import Path
import subprocess,sys,tempfile,json,hashlib
root=Path(__file__).resolve().parent
p=root/'work/micucumber_round2/optimization'
manifest=json.loads((root/'SHA256SUMS.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Frozen file checksums PASS',len(manifest),flush=True)
subprocess.run(['c++','-O3','-std=c++17',str(p/'independent_scan.cpp'),'-o',str(p/'independent_scan')],check=True)
subprocess.run([sys.executable,str(p/'validate_targets.py')],check=True)
subprocess.run([str(p/'independent_scan'),str(p)],check=True)
for script in ['summarize_round2.py','physical_resolution.py']:
 subprocess.run([sys.executable,str(p/script)],check=True)
print('Revalidation complete. See outputs/MiCucumber_round2/validation.json',flush=True)
