MiCucumber round 2 — frozen computational evidence / 冻结计算证据
Install Python 3.12 dependencies: python -m pip install -r requirements.txt
Re-run independent validation: python run_revalidation.py
Requires a C++17 compiler on PATH. This checks frozen hashes, scans original target/background sequences, compares Python/C++ results, and recomputes portfolio and physical-barcode tables.
Optimization: work/micucumber_round2/optimization/optimize_verified.py can re-run MILP on the verified candidate pool after installing SciPy. Global primer optimality is not claimed.
Discovery source, candidate masks and risk tables are included for inspection. Legacy setup scripts contain historical input-tree dependencies and are provenance records, not standalone fresh-download commands. The supported one-command entry point reproduces final validation, not NCBI retrieval or all discovery stages.
Separate PCRs only. No wet-lab validation. Copyright: see outputs/MiCucumber_round2/COPYRIGHT.md.
