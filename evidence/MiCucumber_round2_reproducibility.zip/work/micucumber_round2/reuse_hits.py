from pathlib import Path
import json,shutil
p=Path(__file__).resolve().parent/'optimization/same_locus';old=p/'background_hits_before_orientation_fix'
if not old.exists():(p/'background_hits').rename(old)
(p/'background_hits').mkdir(exist_ok=True)
lookup={}
for f in old.glob('*.json'):
 d=json.loads(f.read_text());lookup[d['side'],d['sequence']]=f
n=0
for r in json.loads((p/'oligos.json').read_text()):
 f=lookup.get((r['side'],r['sequence']))
 if f:
  d=json.loads(f.read_text());d['id']=r['id'];(p/'background_hits'/f"{r['id']}.json").write_text(json.dumps(d));n+=1
print('Reused',n,'sequence-verified caches')
