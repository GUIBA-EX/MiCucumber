from pathlib import Path
from Bio import SeqIO
import csv,json,shutil
p=Path(__file__).resolve().parent;src=p.parent/'micucumber';q=p/'optimization';q.mkdir(exist_ok=True);(q/'same_locus').mkdir(exist_ok=True)
newids={'OZ560339.1','OZ478141.1'}
raw=list(SeqIO.parse(src/'target.fasta','fasta'));extra=[r for r in SeqIO.parse(p/'apodida.gb','genbank') if r.id in newids];SeqIO.write(raw+extra,q/'target.fasta','fasta')
al=[r for r in SeqIO.parse(p/'expanded_aligned.fasta','fasta') if r.id.removeprefix('_R_') in newids or r.id.removeprefix('_R_') in {x.id for x in raw}];SeqIO.write(al,q/'target_aligned.fasta','fasta')
for fn in ['metadata.tsv','target_taxonomy.tsv']:
 rows=list(csv.DictReader((src/fn).open(),delimiter='\t'));fields=list(rows[0])
 for r in extra:
  row={k:'' for k in fields};row.update(accession=r.id,organism=r.annotations['organism'])
  if fn=='metadata.tsv':row.update(clade='Holothuroidea',role='target',status='homology_inferred_16S_full_genome_scan',length=len(r))
  else:row.update(order='Apodida',taxonomy=';'.join(r.annotations['taxonomy']),source='NCBI_download_round2')
  rows.append(row)
 with (q/fn).open('w') as f:w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows(rows)
for fn in ['background.fasta','final_selected.json','common_panel.json','scan_core.py','baselines.json','independent_scan','fast_rank']:
 shutil.copy2(src/fn,q/fn)
(q/'config.json').write_text(json.dumps({'reference':'AB525437.1'}))
s=(p.parent/'miurchin/design_complements.py').read_text()
s=s.replace("len(t)==L and set(t)<=set('ACGT')", "abs(len(t)-L)<=4 and 18<=len(t)<=36 and set(t)<=set('ACGT')")
s=s.replace("list(t) if ok else list('N'*L)","list(t) if ok and len(t)==L else list('N'*L)")
s=s.replace("if valid[j] and w[j]>0:","if valid[j] and len(ts[j])==L and w[j]>0:")
s=s.replace("np.flatnonzero(valid&(w>0))","[j for j in range(len(ids)) if valid[j] and len(ts[j])==L and w[j]>0]")
s=s.replace("queries={seed[side]:'seed'}", "queries={seed[side]:'seed'}\n  for prior in csv.DictReader((p.parents[2]/'outputs/MiCucumber/results/final_separate_pairs.csv').open()):\n   if prior['scheme'].startswith(group+'-'):queries[prior[side]]='published'")
(q/'design_complements.py').write_text(s)
for fn in ['screen_background.py','prepare_fast_rank.py','scan_core.py']:
 shutil.copy2(src/fn,q/'same_locus'/fn)
for fn in ['background.fasta','metadata.tsv']:
 
 if not (q/'same_locus'/fn).exists():(q/'same_locus'/fn).symlink_to(q/fn)
print('Prepared',len(raw)+len(extra),'targets',len(al),'alignment rows')
