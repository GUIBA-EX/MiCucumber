from Bio import SeqIO,Align
from Bio.SeqRecord import SeqRecord
from pathlib import Path
import csv
p=Path(__file__).resolve().parent
refs=[r for r in SeqIO.parse(p/'annotated_16S.fasta','fasta') if len(r)>1000]
a=Align.PairwiseAligner(mode='local',match_score=2,mismatch_score=-2,open_gap_score=-5,extend_gap_score=-.5)
out=[];rows=[]
for r in SeqIO.parse(p/'apodida.gb','genbank'):
 if len(r)<3000 or any(f.type=='rRNA' for f in r.features):continue
 best=None
 for strand,s in [('+',r.seq),('-',r.seq.reverse_complement())]:
  for ref in refs:
   score=a.score(str(s),str(ref.seq))
   if best is None or score>best[0]:best=(score,strand,s,ref)
 score,strand,s,ref=best;al=a.align(str(s),str(ref.seq))[0];start,end=int(al.aligned[0][0][0]),int(al.aligned[0][-1][1]);cov=sum(y-x for x,y in al.aligned[1])/len(ref)
 seq=s[start:end];out.append(SeqRecord(seq,id=r.id,description=r.annotations.get('organism','')+' inferred_16S'))
 rows.append(dict(accession=r.id,organism=r.annotations.get('organism',''),strand=strand,start_0=start,end_0=end,length=len(seq),reference=ref.id,aligned_reference_fraction=cov,score=score,unverified='UNVERIFIED' in r.description,status='homology_inferred_requires_review'))
SeqIO.write(out,p/'inferred_16S.fasta','fasta')
with (p/'inferred_regions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(rows)
