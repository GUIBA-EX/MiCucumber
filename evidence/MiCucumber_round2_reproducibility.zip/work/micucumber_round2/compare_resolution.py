from Bio import SeqIO
from pathlib import Path
import csv,json,itertools,collections
p=Path(__file__).resolve().parent;old=p.parent/'micucumber';out=p.parents[1]/'outputs'/'MiCucumber_round2';out.mkdir(exist_ok=True)
al={r.id:str(r.seq).upper() for r in SeqIO.parse(p/'expanded_aligned.fasta','fasta')};meta={r['accession']:r['organism'] for r in csv.DictReader((old/'target_taxonomy.tsv').open(),delimiter='\t')};audit=list(csv.DictReader((p/'inferred_regions.csv').open()));meta.update({r['accession']:r['organism'] for r in audit});exclude={r['accession'] for r in audit if r['unverified']=='True'};coords=[i for i,c in enumerate(al['AB525437.1']) if c!='-'];seeds=json.loads((old/'final_selected.json').read_text())[:4];regions={}
for s in seeds:
 a=int(s['left'])+len(s['F']);b=int(s['right'])-len(s['R']);d={}
 for k,v in al.items():
  name=meta.get(k,'');parts=name.split()
  if k in exclude or len(parts)!=2 or parts[1] in ['sp.','sp','cf.','aff.']:continue
  sub=v[coords[a]:coords[b-1]+1]
  if v[coords[a]]=='-' or v[coords[b-1]]=='-' or set(sub)-set('ACGT-'):continue
  d[k]=sub.replace('-','')
 regions[s['label']]=d
common=set.intersection(*(set(d) for d in regions.values()));rows=[];coll=[]
for label,d in regions.items():
 for panel,ids in [('own_region',set(d)),('common_all_lengths',common)]:
  by=collections.defaultdict(set)
  for k in ids:by[d[k]].add(meta[k])
  names={meta[k] for k in ids};pairs=set();affected=set()
  for seq,ns in by.items():
   if len(ns)>1:
    affected.update(ns)
    for a,b in itertools.combinations(sorted(ns),2):pairs.add((a,b))
  rows.append(dict(locus=label,panel=panel,records=len(ids),name_labels=len(names),distinct_barcodes=len(by),shared_barcodes=sum(len(ns)>1 for ns in by.values()),affected_labels=len(affected),identical_barcode_label_pairs=len(pairs),labels_without_observed_collision_pct=100*(len(names)-len(affected))/len(names)))
  for a,b in sorted(pairs):coll.append(dict(locus=label,panel=panel,label_a=a,label_b=b))
for fn,data in [('resolution_comparison.csv',rows),('barcode_collisions.csv',coll),('inferred_reference_audit.csv',audit)]:
 with (out/fn).open('w') as h:
  w=csv.DictWriter(h,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print(json.dumps(rows,indent=2))
