from pathlib import Path
import csv,json,shutil,hashlib,html,sys,zipfile,collections
root=Path(__file__).resolve().parents[2];p=Path(__file__).resolve().parent/'optimization';out=root/'outputs/MiCucumber_round2';read=lambda f:list(csv.DictReader(open(f)))
rows=read(out/'recommended_comparison.csv');sels=json.loads((p/'recommended_sets.json').read_text());selected={s['name'] for s in sels};pairs=read(out/'recommended_pairs.csv');thermal=list(csv.DictReader((p/'thermal/pair_thermodynamics.tsv').open(),delimiter='\t'))
assert len({r['name'] for r in thermal})==len({r['pair_id'] for r in pairs})
structure=[float(v) for r in thermal for k,v in r.items() if k.endswith(('hairpin_max','homodimer_max','heterodimer_max'))];assert max(structure)<55
shutil.copy2(p/'thermal/pair_thermodynamics.tsv',out/'pair_thermodynamics.tsv')
with (out/'recommended_primers.fasta').open('w') as f:
 for r in pairs:
  for side in ['F','R']:f.write(f">{r['scheme']}|PCR{r['reaction']}|{side}|{r['pair_id']}\n{r[side]}\n")
for fn in ['reference_audit.csv','inferred_regions.csv','orientation_audit.json','apodida_search.json']:
 shutil.copy2(p.parent/fn,out/fn)
shutil.copy2(root/'outputs/MiCucumber/COPYRIGHT.md',out/'COPYRIGHT.md')
# Re-evaluate taxon-level missing haplotypes from independently validated details.
tab=collections.defaultdict(dict)
for r in csv.DictReader((p/'target_detail.tsv').open(),delimiter='\t'):tab[r['name'],r['panel']][r['accession']]=r
tax={r['accession']:r for r in csv.DictReader((p/'target_taxonomy.tsv').open(),delimiter='\t')};coverage=[]
for s in sels:
 for panel in ['common','own_region']:
  rr=tab[s['pair_names'][0],panel];groups=collections.defaultdict(list)
  for k,v in rr.items():groups[v['organism']].append(k)
  for label,ids in groups.items():
   d=dict(scheme=s['name'],panel=panel,organism=label,source_order=tax[ids[0]]['order'],n_haplotypes=len(ids))
   for metric in ['exact','le2last3']:d[metric+'_pct']=100*sum(any(tab[n,panel][k][metric]=='True' for n in s['pair_names']) for k in ids)/len(ids)
   coverage.append(d)
with (out/'taxon_coverage.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(coverage[0]));w.writeheader();w.writerows(coverage)
# Plot common-panel comparison.
sys.path.insert(0,str(root/'work/plotdeps'));import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
common=[r for r in rows if r['panel']=='common'];ordered=[]
for locus in ['MiCucumber-v4opt','MiCucumber-S','MiCucumber-M','MiCucumber-L']:
 ordered.extend(sorted([r for r in common if r['locus']==locus],key=lambda r:(r['stage']!='published',int(r['count']))))
labels=[r['locus'].replace('MiCucumber-','')+(' published' if r['stage']=='published' else ' round 2')+f" / {r['count']} PCRs" for r in ordered]
fig,ax=plt.subplots(figsize=(10,6));y=list(range(len(ordered)));ax.barh(y,[float(r['le2last3_pct']) for r in ordered],color='#cbd5e1',label='≤2 mismatches per primer; last 3 exact');ax.barh(y,[float(r['exact_pct']) for r in ordered],color='#087f8c',label='Both primers exact');ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xlabel('Equal-label / within-label-haplotype weighted coverage (%)');ax.legend(loc='lower right',fontsize=8);ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(out/'coverage_comparison.png',dpi=180);fig.savefig(out/'coverage_comparison.svg');plt.close(fig)

def table(headers,data):return '<table><thead><tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in data)+'</tbody></table>'
tabrows=[]
for r in ordered:
 tabrows.append([r['locus'].replace('MiCucumber-',''), '原版 / Published' if r['stage']=='published' else '新候选 / Round 2',r['count'],f"{float(r['exact_pct']):.2f}%",f"{float(r['le2last3_pct']):.2f}%",f"{float(r['Apodida_le2last3_pct']):.1f}%",r['WC_le3'],r['GT_le2'],r['WC_le4']])
res=[r for r in read(out/'resolution_comparison.csv') if r['panel']=='matched_physical_all_lengths'];audit=json.loads((out/'validation.json').read_text());audit['thermal_scenarios']=2;audit['maximum_structure_tm_C']=max(structure);audit['reference_orientation_corrected']=True;audit['solver_scope']='MILP optimum only within the verified candidate pool; heuristic discovery, no global primer optimum or held-out validation';(out/'validation.json').write_text(json.dumps(audit,indent=2))
text='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>MiCucumber Round 2</title><style>body{max-width:1150px;margin:40px auto;padding:0 24px;font:16px/1.7 system-ui;color:#172b3a}h1,h2{color:#087f8c}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left}th{background:#edf6f6}img{max-width:100%}.note{background:#fff4db;padding:16px;border-radius:8px}a{color:#087f8c}small{color:#516270}</style><h1>MiCucumber 第二轮计算优化<br><small>Round 2 computational optimization</small></h1>
<p>目标：增加 Apodida 参考、提高完全匹配率、精简组合，并保留四个长度区域比较。全部方案均为独立 PCR 后合并结果；不是经验证的单管混池方案。</p><p>Objectives: expand Apodida references, increase exact-match coverage, reduce reaction count where feasible, and compare four regions. All portfolios represent separate PCRs; pooled-tube performance has not been established.</p>
<h2>覆盖与非目标取舍 / Coverage and off-target trade-offs</h2>'''
text+=f"<p>共同覆盖面板：{ordered[0]['n_labels']} 个分类名称标签 / {ordered[0]['n_haplotypes']} 个标签内单倍型。旧方案在同一面板上重新计算，不能直接与旧发布百分比混比。Own-region panels and taxon-level detail are supplied separately.</p>"
text+=table(['区域 / Region','方案 / Stage','PCR数','完全匹配 / Exact','允许错配 / Coverage','Apodida coverage','WC≤3','GT≤2','WC≤4'],tabrows)
text+='''<p>v4opt 优先用于后续验证；S 同时保留较高完全匹配版与较少反应版。M 的较高完全匹配方案需结合 WC≤4 风险评估；完整候选表保留低风险替代方案。L 保留用于长度与分辨率对照，不将其较低覆盖率包装成通用性。</p><p>Prioritize v4opt for subsequent testing. Keep both S alternatives. Consider the WC≤4 sensitivity of the higher-exact M option; lower-risk alternatives remain in the full table. Retain L as a length/resolution comparator.</p><img src="coverage_comparison.png" alt="Common panel exact and mismatch-tolerant coverage comparison">
<h2>分辨率 / Sequence discrimination</h2><p>修正反向记录标识和新增序列方向后，从原始序列提取固定同源、去引物窗口；不使用删掉插入位点的比对串作为条形码。仅在四区域均能定位的相同记录上作公平比较；覆盖面板与分辨率面板不同。</p><p>Fixed homologous primer-free windows were mapped back to original sequences, retaining insertions. Fair comparison uses the intersection resolvable in all four regions and does not require successful primer amplification.</p>'''
text+=table(['区域','Records','Labels','共享条形码标签对 / Identical','≤1 edit label pairs'],[[r['locus'],r['evaluable_records'],r['name_labels'],r['identical_label_pairs'],r['label_pairs_with_edit_distance_le1']] for r in res])
text+='''<p>完全相同或仅差 1 个编辑的跨标签序列表示潜在鉴定歧义，不是实际物种鉴定准确率。名称未做同物异名统一；缺失参考与误鉴定也会影响结果。M/L 的共享条形码情况与近邻差异均应一起判断。</p>
<h2>参考数据与方法 / References and methods</h2><p>NCBI 检索获得 203 条记录，包含许多 COI 序列；17 个已注释 16S 区段均已在原库。另定位 8 个未注释线粒体 16S 候选；6 条 UNVERIFIED 记录排除，OZ560339.1 与 OZ478141.1 以明确标记的同源推断参考纳入。新增序列按 AB525437.1 方向核验并重比对。覆盖扫描使用原始完整线粒体序列，而非只扫描推断片段。新数据不是独立验证集。</p><p>The two additional loci remain homology-inferred rather than curated 16S annotations. Six UNVERIFIED genomes are excluded from primary design. Both original strands are scanned. Database names and legacy orders are not synonym-reconciled; these are reference-label estimates.</p><p>各区域按分类名称等权、标签内单倍型等权；同位置实际序列和低简并共识产生候选。探索 WC≤3/GT≤2 背景记录并集上限 5、20、50，并比较不同组合大小。推荐方案限制每种模型≤20、两类面板覆盖损失≤0.5百分点、区域面板 Apodida 覆盖不降、完全匹配率提高且引物对数不超过旧版。MILP 仅在完成全序列复核的候选池内优化；简约替代要求两面板完全匹配率至少比旧版提高1百分点，再最小化反应数。</p><p>Thermodynamics: Primer3, 50 mM monovalent ions, 1.5 mM Mg, 0.6 mM dNTP. Expanded IUPAC variants were checked at 50 nM per variant and at 200 nM per direction divided among variants. Unequal F/R cross-dimer calculations use the larger variant concentration. These are screening assumptions, not an optimized laboratory recipe. Homopolymers are reported, not automatically excluded.</p>
<p class="note">背景库仍为 5,600 条既有参考，主要覆盖棘皮动物，并未扩展成完整海洋环境库。WC/GT 命中为预测风险记录数，不是物种数、PCR 概率或 reads 占比；GT 是宽松敏感性模型。WC≤4 残余风险和模糊碱基命中单独保留。计算结果不能替代组织、模拟群落和实际 eDNA 验证。</p>'''
text+=f"<p>验证：{audit['unique_pairs']} 个独立候选配对，另含两套历史基线；Python 与独立 C++ 扫描完成 {audit['comparisons']:,} 项一致性检查。热力学两种浓度场景均通过既定结构阈值，最大结构 Tm={max(structure):.2f} °C。No wet-lab validation.</p>"
text+='''<h2>下载 / Files</h2><ul><li><a href="recommended_pairs.csv">引物配对与序列 / Primer pairs</a> · <a href="recommended_primers.fasta">FASTA</a></li><li><a href="recommended_comparison.csv">推荐方案与旧版对照 / Recommended comparison</a> · <a href="all_scheme_comparison.csv">全部取舍 / All portfolios</a></li><li><a href="recommended_offtargets.csv">非目标命中明细 / Off-target records</a> · <a href="taxon_coverage.csv">分类群覆盖 / Taxon coverage</a></li><li><a href="resolution_comparison.csv">分辨率 / Resolution</a> · <a href="barcode_collisions.csv">冲突与近邻 / Collisions and near neighbours</a></li><li><a href="pair_thermodynamics.tsv">热力学 / Thermodynamics</a> · <a href="validation.json">验证记录 / Validation</a></li><li><a href="MiCucumber_round2_reproducibility.zip">冻结数据与复核脚本 / Frozen data and revalidation scripts</a></li></ul><p>Copyright © 2026 Fei Xia (GUIBA-EX). All rights reserved. <a href="COPYRIGHT.md">版权与使用声明 / Copyright and permissions</a>. Third-party reference-data rights remain with their owners.</p></html>'''
(out/'report.html').write_text(text)
print('Report and figures created')
