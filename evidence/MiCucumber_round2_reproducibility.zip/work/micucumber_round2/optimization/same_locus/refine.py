from pathlib import Path
import json,csv,functools,collections,itertools,sys
import numpy as np
from scan_core import database
p=Path(__file__).resolve().parent
ol=json.loads((p/'oligos.json').read_text());by={x['id']:x for x in ol};idx={x['id']:i for i,x in enumerate(ol)};z=np.load(p/'discovery_masks.npz');m=z['coverage'];e=z['exact'];manifest=json.loads((p/'design_manifest.json').read_text());ids=manifest['panel_ids'];tax={r['accession']:r for r in csv.DictReader((p.parent/'target_taxonomy.tsv').open(),delimiter='\t')};rows=json.loads((p/'rank_pair_order.json').read_text());risks=list(csv.DictReader((p/'fast_risks.tsv').open(),delimiter='\t'))
for i,(r,v) in enumerate(zip(rows,risks)):
 r.update({k:int(x) for k,x in v.items() if k!='index'});r['index']=i
refs=database(p/'background.fasta')[3]
@functools.lru_cache(None)
def hits(k):return json.loads((p/'background_hits'/f'{k}.json').read_text())['hits']
@functools.lru_cache(None)
def residual(i,model):
 r=rows[i];th=3 if model=='WC' else 2
 if r['WC_le3' if model=='WC' else 'GT_le2']==0:return frozenset()
 fh=hits(r['F_id'])[model];rh=hits(r['R_id'])[model];found=set()
 for rec in fh.keys()&rh.keys():
  for fp,fm,f5,fa in fh[rec]:
   if fa or fm>th:continue
   for rp,rm,r5,ra in rh[rec]:
    if not ra and rm<=th and 0<=rp-fp-len(r['F'])<=1000:found.update(refs[int(rec)]['accessions'])
 assert len(found)==r['WC_le3' if model=='WC' else 'GT_le2']
 return frozenset(found)
import primer3
from Bio.Data.IUPACData import ambiguous_dna_values as I
@functools.lru_cache(None)
def vs(q):return [''.join(t) for t in itertools.product(*(I[c] for c in q))]
@functools.lru_cache(None)
def sidepass(q):
 v=vs(q);kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=50)
 return all(primer3.calc_heterodimer(a,b,**kw).tm<55 for a in v for b in v)
@functools.lru_cache(None)
def pairpass(i):
 r=rows[i];kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=50)
 return sidepass(r['F']) and sidepass(r['R']) and all(primer3.calc_heterodimer(a,b,**kw).tm<55 for a in vs(r['F']) for b in vs(r['R']))
solutions=[]
for group in sorted(manifest['locus_panels']):
 w=z['weights_'+group];aw=w*np.array([tax[k]['order']=='Apodida' for k in ids]);aw=aw/aw.sum();objective=.85*w+.15*aw
 for budget in [5,20,50]:
  candidates=[r for r in rows if r['band']==group and r['WC_le3']<=budget and r['GT_le2']<=budget]
  # Collapse identical target masks, retaining low-risk, low-degeneracy alternatives.
  buckets=collections.defaultdict(list)
  for r in candidates:
   fi,ri=idx[r['F_id']],idx[r['R_id']];r['_m']=m[fi]&m[ri];r['_e']=e[fi]&e[ri];buckets[(r['_m'].tobytes(),r['_e'].tobytes())].append(r)
  cand=[]
  for rr in buckets.values():cand.extend(sorted(rr,key=lambda r:(r['WC_le3']+r['GT_le2'],r['WC_le4'],int(r['degeneracy_sum'])))[:2])
  cm=np.array([r['_m'] for r in cand]);ce=np.array([r['_e'] for r in cand]);ci=[r['index'] for r in cand]
  def assess(js):
   mm=cm[js].any(0);ee=ce[js].any(0);wc=set().union(*(residual(ci[j],'WC') for j in js));gt=set().union(*(residual(ci[j],'GT') for j in js))
   if len(wc)>budget or len(gt)>budget:return None
   return dict(indices=[ci[j] for j in js],coverage=float(w[mm].sum()),exact=float(w[ee].sum()),apodida_coverage=float(aw[mm].sum()),apodida_exact=float(aw[ee].sum()),WC3_accessions=sorted(wc),GT2_accessions=sorted(gt),score_coverage=float(objective[mm].sum()),score_exact=float(objective[ee].sum()))
  for alpha in [0,.25,1,4]:
   chosen=[];mask=np.zeros(len(ids),bool);exact=mask.copy()
   for cap in range(1,10):
    scores=(cm|mask)@objective+alpha*((ce|exact)@objective)
    order=sorted(range(len(cand)),key=lambda j:(-scores[j],cand[j]['WC_le4'],int(cand[j]['degeneracy_sum'])))
    best=None
    for j in order:
     if j in chosen:continue
     if scores[j]<=float(objective[mask].sum()+alpha*objective[exact].sum())+1e-10:break
     trial=assess(chosen+[j])
     if trial is not None and pairpass(ci[j]):best=j;break
    if best is None:break
    chosen.append(best);mask|=cm[best];exact|=ce[best];res=assess(chosen)
    solutions.append(dict(res,locus=group,budget=budget,alpha=alpha,count=len(chosen),mode='separate'))
  print(group,budget,'candidate_pairs',len(cand),'best',solutions[-1]['coverage'],solutions[-1]['exact'],flush=True)
 # Persist after each locus.
 (p/'round2_search.json').write_text(json.dumps(solutions,indent=2))
print('DONE',len(solutions),flush=True)
