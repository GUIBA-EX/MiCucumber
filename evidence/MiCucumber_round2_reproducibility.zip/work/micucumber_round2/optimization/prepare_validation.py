from pathlib import Path
import csv,json,shutil
p=Path(__file__).resolve().parent;q=p/'same_locus';root=p.parents[2]
solutions=json.loads((q/'round2_search.json').read_text());rows=json.loads((q/'rank_pair_order.json').read_text());risk=list(csv.DictReader((q/'fast_risks.tsv').open(),delimiter='\t'))
for r,a in zip(rows,risk):r.update({k:int(v) for k,v in a.items() if k!='index'})
seeds={s['label']:s for s in json.loads((p/'final_selected.json').read_text())[:4]};pairs={};sets=[]
def add(F,R,locus,riskrow=None):
 key=(F,R)
 if key not in pairs:
  s=seeds[locus];name=f'R2P{len(pairs):03d}';pairs[key]=dict(name=name,F=F,R=R,left=int(s['left']),right=int(s['right']),group=locus)
  if riskrow:pairs[key].update({k:v for k,v in riskrow.items() if k.startswith(('WC_','GT_'))})
 return pairs[key]['name']
for n,s in enumerate(solutions):
 names=[add(rows[i]['F'],rows[i]['R'],s['locus'],rows[i]) for i in s['indices']]
 sets.append(dict(name=f"R2_{s['locus']}_B{s['budget']}_A{s['alpha']}_N{s['count']}",locus=s['locus'],stage='round2',budget=s['budget'],alpha=s['alpha'],pair_names=names,count=len(names)))
old=__import__('collections').defaultdict(list)
for r in csv.DictReader((root/'outputs/MiCucumber/results/final_separate_pairs.csv').open()):old[r['scheme']].append(r)
for name,rr in old.items():
 locus=name.split('-Separate')[0];names=[add(r['F'],r['R'],locus) for r in rr];sets.append(dict(name=name,locus=locus,stage='published',budget='',alpha='',pair_names=names,count=len(names)))
(p/'shortlist_fast.json').write_text(json.dumps(list(pairs.values()),indent=2));(p/'validation_sets.json').write_text(json.dumps(sets,indent=2))
with (p/'independent_primers.tsv').open('w') as f:
 for r in pairs.values():f.write(f"{r['name']}\t{r['F']}\t{r['R']}\n")
 for r in json.loads((p/'baselines.json').read_text()):f.write(f"{r['name']}\t{r['F']}\t{r['R']}\n")
s=(p.parents[1]/'micucumber/validate_targets.py').read_text().replace('assert len(al)==1846','assert len(al)==1848')
(p/'validate_targets.py').write_text(s)
print('Unique pairs',len(pairs),'schemes',len(sets))
