from pathlib import Path
import sys,csv,json,collections
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p.parent/'deps'))
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
sets=json.loads((p/'validation_sets.json').read_text());pairs=json.loads((p/'shortlist_fast.json').read_text());by={r['name']:r for r in pairs};tax={r['accession']:r for r in csv.DictReader((p/'target_taxonomy.tsv').open(),delimiter='\t')};details=collections.defaultdict(dict)
for r in csv.DictReader((p/'target_detail.tsv').open(),delimiter='\t'):details[r['name'],r['panel']][r['accession']]=r
h=collections.defaultdict(dict)
for r in csv.DictReader((p/'independent_hits.tsv').open(),delimiter='\t'):h[r['name'],r['role'],r['model']][r['accession']]=r
added=[];logs=[]
for locus in sorted({s['locus'] for s in sets}):
 old=next(s for s in sets if s['locus']==locus and s['stage']=='published');cand=[r['name'] for r in pairs if r['group']==locus];ids=sorted(set(details[cand[0],'common'])|set(details[cand[0],'own_region']));N=len(cand);T=len(ids)
 w={panel:np.array([float(details[cand[0],panel].get(k,{}).get('weight',0)) for k in ids]) for panel in ['common','own_region']};aw=w['own_region']*np.array([tax[k]['order']=='Apodida' for k in ids]);aw/=aw.sum()
 cm=np.array([[h[n,'target','WC'].get(k,{}).get('le2last3')=='1' for k in ids] for n in cand]);em=np.array([[h[n,'target','WC'].get(k,{}).get('exact')=='1' for k in ids] for n in cand]);oldix=[cand.index(n) for n in old['pair_names']];oldcov=cm[oldix].any(0)
 bg={mod:[{k for k,r in h[n,'background',mod].items() if r[metric]=='1'} for n in cand] for mod,metric in [('WC','le3'),('GT','le2')]}
 for budget in [5,20,50]:
  keys={mod:sorted(set().union(*bg[mod])) for mod in bg};offset={'WC':N+2*T,'GT':N+2*T+len(keys['WC'])};nv=N+2*T+sum(map(len,keys.values()));rs=[];lower=[];upper=[]
  def con(d,lo=-np.inf,hi=np.inf):rs.append(d);lower.append(lo);upper.append(hi)
  for j in range(T):
   con({N+j:1,**{int(i):-1 for i in np.flatnonzero(cm[:,j])}},hi=0)
   con({N+T+j:1,**{int(i):-1 for i in np.flatnonzero(em[:,j])}},hi=0)
  for panel in w:con({N+j:float(v) for j,v in enumerate(w[panel]) if v},lo=float(w[panel][oldcov].sum())-.005)
  con({N+j:float(v) for j,v in enumerate(aw) if v},lo=float(aw[oldcov].sum())-1e-9)
  con({i:1 for i in range(N)},hi=old['count'])
  for mod in bg:
   ki={k:offset[mod]+j for j,k in enumerate(keys[mod])}
   for i,ss in enumerate(bg[mod]):
    for k in ss:con({i:1,ki[k]:-1},hi=0)
   con({j:1 for j in ki.values()},hi=budget)
  objective=.425*w['common']+.425*w['own_region']+.15*aw
  cost=np.zeros(nv);cost[N+T:N+2*T]=-objective
  def solve(c):
   ii=[];jj=[];vv=[]
   for i,d in enumerate(rs):
    for j,v in d.items():ii.append(i);jj.append(j);vv.append(v)
   A=coo_matrix((vv,(ii,jj)),shape=(len(rs),nv)).tocsc();integ=np.zeros(nv);integ[:N]=1
   return milp(c,integrality=integ,bounds=Bounds(np.zeros(nv),np.ones(nv)),constraints=LinearConstraint(A,np.array(lower),np.array(upper)),options={'time_limit':40,'mip_rel_gap':.0001})
  res=solve(cost)
  if res.x is None:logs.append(dict(locus=locus,budget=budget,phase='exact',status=int(res.status),message=res.message));continue
  chosen=np.flatnonzero(res.x[:N]>.5);maxmask=em[chosen].any(0)
  base_constraints=len(rs)
  for phase in ['exact','compact','lean']:
   if phase in ['compact','lean']:
    del rs[base_constraints:];del lower[base_constraints:];del upper[base_constraints:]
    for panel in w:con({N+T+j:float(v) for j,v in enumerate(w[panel]) if v},lo=(max(0,float(w[panel][maxmask].sum())-.01) if phase=='compact' else float(w[panel][em[oldix].any(0)].sum())+.01))
    c=np.zeros(nv);c[:N]=1;rr=solve(c)
    if rr.x is None:continue
    chosen=np.flatnonzero(rr.x[:N]>.5);con({i:1 for i in range(N)},hi=len(chosen));rr2=solve(cost)
    if rr2.x is not None:rr=rr2;chosen=np.flatnonzero(rr.x[:N]>.5)
    res=rr
   s=dict(name=f'R2_{locus}_B{budget}_MILP_{phase}',locus=locus,stage='round2',budget=budget,alpha='MILP_'+phase,pair_names=[cand[i] for i in chosen],count=len(chosen));added.append(s);logs.append(dict(locus=locus,budget=budget,phase=phase,status=int(res.status),message=res.message,gap=float(getattr(res,'mip_gap',0)),count=len(chosen)))
   print(s['name'],len(chosen),'coverage',[round(100*x[cm[chosen].any(0)].sum(),2) for x in w.values()],'exact',[round(100*x[em[chosen].any(0)].sum(),2) for x in w.values()],flush=True)
 (p/'milp_log.json').write_text(json.dumps(logs,indent=2));(p/'milp_sets.json').write_text(json.dumps(added,indent=2))
base=[s for s in sets if 'MILP' not in s['name']];(p/'validation_sets.json').write_text(json.dumps(base+added,indent=2))
