from pathlib import Path
from Bio import SeqIO,Align
import csv,json,collections,itertools
p=Path(__file__).resolve().parent;out=p.parents[2]/'outputs/MiCucumber_round2'
raw={r.id:str(r.seq).upper() for r in SeqIO.parse(p/'target.fasta','fasta')};al={};reverse=set()
for r in SeqIO.parse(p/'target_aligned.fasta','fasta'):
 k=r.id.removeprefix('_R_');al[k]=str(r.seq).upper()
 if r.id.startswith('_R_'):reverse.add(k)
for r in csv.DictReader((p.parent/'inferred_regions.csv').open()):
 if (r['strand']=='-') != json.loads((p.parent/'orientation_audit.json').read_text())[r['accession']]['flipped']:reverse.add(r['accession'])
meta={r['accession']:r['organism'] for r in csv.DictReader((p/'target_taxonomy.tsv').open(),delimiter='\t')};seeds=json.loads((p/'final_selected.json').read_text())[:4];detail=collections.defaultdict(set);pairs={r['name']:r['group'] for r in json.loads((p/'shortlist_fast.json').read_text())}
for r in csv.DictReader((p/'target_detail.tsv').open(),delimiter='\t'):
 if r['name'] in pairs:detail[pairs[r['name']],r['panel']].add(r['accession'])
coords=[i for i,c in enumerate(al['AB525437.1']) if c!='-'];aligner=Align.PairwiseAligner(mode='local',match_score=3,mismatch_score=-10,open_gap_score=-5,extend_gap_score=-.2);mapping={};audit=[]
from Bio.Seq import Seq
for k in sorted(set().union(*detail.values())):
 seq=str(Seq(raw[k]).reverse_complement()) if k in reverse else raw[k];q=al[k].replace('-','');start=seq.find(q)
 if start>=0:mp={i:start+i for i in range(len(q))}
 else:
  a=aligner.align(seq,q)[0];mp={}
  for (x,y),(u,v) in zip(a.aligned[0],a.aligned[1]):
   for j in range(int(v-u)):
    if seq[int(x)+j]==q[int(u)+j]:mp[int(u)+j]=int(x)+j
 valid=len(mp)/len(q)>=.95;mapping[k]=(seq,mp) if valid else None;audit.append(dict(accession=k,matched_alignment_fraction=len(mp)/len(q),usable=valid))
rows=[];collisions=[];bars=[]
for s in seeds:
 locus=s['label'];a=coords[int(s['left'])+len(s['F'])];b=coords[int(s['right'])-len(s['R'])-1]
 for panel in ['common','own_region']:
  groups=collections.defaultdict(set);count=0;failed=[]
  for k in sorted(detail[locus,panel]):
   if mapping[k] is None or al[k][a]=='-' or al[k][b]=='-':failed.append(k);continue
   seq,mp=mapping[k];u=len(al[k][:a].replace('-',''));v=len(al[k][:b+1].replace('-',''))-1
   if u not in mp or v not in mp:failed.append(k);continue
   barcode=seq[mp[u]:mp[v]+1]
   if set(barcode)-set('ACGT'):failed.append(k);continue
   groups[barcode].add(meta[k]);count+=1;bars.append(dict(locus=locus,panel=panel,accession=k,organism=meta[k],sequence=barcode))
  exact=set();one=set();sub=collections.defaultdict(set)
  for seq,names in groups.items():
   exact.update(itertools.combinations(sorted(names),2))
   for j in range(len(seq)):
    sub[(len(seq),j,seq[:j]+seq[j+1:])].update(names)
    shorter=seq[:j]+seq[j+1:]
    for a1 in names:
     for b1 in groups.get(shorter,[]):
      if a1!=b1:one.add(tuple(sorted((a1,b1))))
  for names in sub.values():one.update(itertools.combinations(sorted(names),2))
  one|=exact;labels=set().union(*groups.values());affected=set().union(*(set(t) for t in exact)) if exact else set()
  rows.append(dict(locus=locus,panel=panel,evaluable_records=count,name_labels=len(labels),unresolved_records=len(failed),unique_physical_barcodes=len(groups),identical_label_pairs=len(exact),labels_with_identical_barcode=len(affected),label_pairs_with_edit_distance_le1=len(one),minimum_bp=min(map(len,groups)),maximum_bp=max(map(len,groups)),scope='fixed homologous primer-free seed window; extracted from original sequences; independent of primer amplification; names not synonym-reconciled'))
  for a1,b1 in sorted(one):collisions.append(dict(locus=locus,panel=panel,label_a=a1,label_b=b1,minimum_distance_category='0' if (a1,b1) in exact else '1'))
common_by={s['label']:{r['accession']:r for r in bars if r['locus']==s['label'] and r['panel']=='common'} for s in seeds}
matched=set.intersection(*(set(d) for d in common_by.values()))
for locus,d in common_by.items():
 groups=collections.defaultdict(set)
 for k in matched:groups[d[k]['sequence']].add(d[k]['organism'])
 exact=set();one=set();sub=collections.defaultdict(set)
 for seq,names in groups.items():
  exact.update(itertools.combinations(sorted(names),2))
  for j in range(len(seq)):
   sub[(len(seq),j,seq[:j]+seq[j+1:])].update(names)
   for a1 in names:
    for b1 in groups.get(seq[:j]+seq[j+1:],[]):
     if a1!=b1:one.add(tuple(sorted((a1,b1))))
 for names in sub.values():one.update(itertools.combinations(sorted(names),2))
 one|=exact;labels=set().union(*groups.values());affected=set().union(*(set(t) for t in exact)) if exact else set()
 rows.append(dict(locus=locus,panel='matched_physical_all_lengths',evaluable_records=len(matched),name_labels=len(labels),unresolved_records=len(detail[locus,'common'])-len(matched),unique_physical_barcodes=len(groups),identical_label_pairs=len(exact),labels_with_identical_barcode=len(affected),label_pairs_with_edit_distance_le1=len(one),minimum_bp=min(map(len,groups)),maximum_bp=max(map(len,groups)),scope='same original-sequence records across four regions; fixed homologous primer-free windows; sequence discrimination only, no amplification requirement'))
 for a1,b1 in sorted(one):collisions.append(dict(locus=locus,panel='matched_physical_all_lengths',label_a=a1,label_b=b1,minimum_distance_category='0' if (a1,b1) in exact else '1'))
(out/'resolution_matched_ids.json').write_text(json.dumps(sorted(matched),indent=2))
for fn,data in [('resolution_comparison.csv',rows),('barcode_collisions.csv',collisions),('physical_barcodes.csv',bars),('physical_mapping_audit.csv',audit)]:
 with (out/fn).open('w') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print(json.dumps(rows,indent=2))
