from pathlib import Path
import csv,json,collections
p=Path(__file__).resolve().parent;out=p.parents[2]/'outputs/MiCucumber_round2';out.mkdir(exist_ok=True)
sets=json.loads((p/'validation_sets.json').read_text());pairs={r['name']:r for r in json.loads((p/'shortlist_fast.json').read_text())};tax={r['accession']:r for r in csv.DictReader((p/'target_taxonomy.tsv').open(),delimiter='\t')};meta={r['accession']:r for r in csv.DictReader((p/'metadata.tsv').open(),delimiter='\t')};tab=collections.defaultdict(dict)
for r in csv.DictReader((p/'target_detail.tsv').open(),delimiter='\t'):tab[r['name'],r['panel']][r['accession']]=r
hits=collections.defaultdict(dict)
for r in csv.DictReader((p/'independent_hits.tsv').open(),delimiter='\t'):hits[r['name'],r['role'],r['model']][r['accession']]=r
checks=0
for (name,panel),rr in tab.items():
 for k,r in rr.items():
  other=hits[name,'target','WC'].get(k,{})
  for metric in ['exact','le2last3','le2']:
   assert (r[metric]=='True')==(other.get(metric,'0')=='1'),(name,k,metric);checks+=1
  assert set(filter(None,r['sizes'].split(',')))==set(filter(None,other.get('sizes','').split(',')));checks+=1
for name,r in pairs.items():
 for model,metrics in [('WC',['le2','le3','le4','ambiguous']),('GT',['le2','ambiguous'])]:
  for metric in metrics:
   if model+'_'+metric in r:
    n=sum(v[metric]=='1' for v in hits[name,'background',model].values());assert n==r[model+'_'+metric],(name,model,metric,n,r[model+'_'+metric]);checks+=1

def assess(s,panel):
 names=s['pair_names'];rr=tab[names[0],panel];assert all(set(tab[n,panel])==set(rr) for n in names)
 row={k:s[k] for k in ['name','locus','stage','budget','alpha','count']};row.update(panel=panel,n_labels=len({r['organism'] for r in rr.values()}),n_haplotypes=len(rr));apo={k for k in rr if tax[k]['order']=='Apodida'};row['Apodida_labels']=len({rr[k]['organism'] for k in apo});den=sum(float(rr[k]['weight']) for k in apo)
 for metric in ['exact','le2last3']:
  detected={k for k in rr if any(tab[n,panel][k][metric]=='True' for n in names)}
  row[metric+'_pct']=100*sum(float(rr[k]['weight']) for k in detected);row['Apodida_'+metric+'_pct']=100*sum(float(rr[k]['weight']) for k in detected&apo)/den if den else 0
 sizes={int(x) for n in names for r in tab[n,panel].values() for x in r['sizes'].split(',') if x};row['product_min']=min(sizes) if sizes else '';row['product_max']=max(sizes) if sizes else ''
 for model,metrics in [('WC',['le2','le3','le4','ambiguous']),('GT',['le2','ambiguous'])]:
  for metric in metrics:row[model+'_'+metric]=len({k for n in names for k,r in hits[n,'background',model].items() if r[metric]=='1'})
 return row
# Remove pairs with zero unique contribution to exact or permissive detection, on both panels and all reference records.
for s in sets:
 if s['stage']!='round2':continue
 def signature(ns):return {(k,metric) for n in ns for k,r in hits[n,'target','WC'].items() for metric in ['exact','le2last3'] if r[metric]=='1'}
 for n in list(reversed(s['pair_names'])):
  remaining=[x for x in s['pair_names'] if x!=n]
  if remaining and signature(remaining)==signature(s['pair_names']):s['pair_names']=remaining
 s['count']=len(s['pair_names'])
summary=[assess(s,panel) for s in sets for panel in ['common','own_region']];lookup={(r['name'],r['panel']):r for r in summary};selected=[]
for locus in sorted({s['locus'] for s in sets}):
 old=next(s for s in sets if s['locus']==locus and s['stage']=='published');base=lookup[old['name'],'own_region'];commonbase=lookup[old['name'],'common']
 possible=[]
 for s in sets:
  if s['locus']!=locus or s['stage']!='round2' or s['budget']>20 or s['count']>old['count']:continue
  r=lookup[s['name'],'own_region'];c=lookup[s['name'],'common']
  if r['le2last3_pct']>=base['le2last3_pct']-.5 and c['le2last3_pct']>=commonbase['le2last3_pct']-.5 and r['Apodida_le2last3_pct']>=base['Apodida_le2last3_pct']-1e-6 and r['exact_pct']>base['exact_pct']:possible.append(s)
 if not possible:
  print('NO qualifying improvement',locus,flush=True);continue
 best=max(possible,key=lambda s:(lookup[s['name'],'own_region']['exact_pct'],lookup[s['name'],'common']['exact_pct']));maxex=lookup[best['name'],'own_region']['exact_pct'];maxcomex=lookup[best['name'],'common']['exact_pct']
 compact=[s for s in possible if lookup[s['name'],'own_region']['exact_pct']>=maxex-1 and lookup[s['name'],'common']['exact_pct']>=maxcomex-1]
 best=min(compact,key=lambda s:(s['count'],lookup[s['name'],'own_region']['WC_le3']+lookup[s['name'],'own_region']['GT_le2'],-lookup[s['name'],'own_region']['exact_pct']))
 selected.append(best);print('SELECTED',lookup[best['name'],'own_region'],flush=True)

primary=selected.copy()
for locus in sorted({s['locus'] for s in selected}):
 options=[s for s in sets if s['locus']==locus and s['name'].endswith('MILP_lean') and s['budget']<=20]
 if options:
  lean=min(options,key=lambda s:(s['count'],s['budget']))
  main=next(s for s in primary if s['locus']==locus)
  if lean['count']<main['count']:selected.append(lean)

def write(fn,rr):
 if not rr:return
 with (out/fn).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
write('all_scheme_comparison.csv',summary);write('recommended_comparison.csv',[lookup[s['name'],panel] for s in sets if s['stage']=='published' or s in selected for panel in ['common','own_region']])
pr=[];bg=[]
for s in selected:
 for j,n in enumerate(s['pair_names'],1):pr.append(dict(scheme=s['name'],locus=s['locus'],reaction=j,pair_id=n,F=pairs[n]['F'],R=pairs[n]['R']))
 for model,metric in [('WC','le3'),('WC','le4'),('GT','le2')]:
  for k in sorted({k for n in s['pair_names'] for k,r in hits[n,'background',model].items() if r[metric]=='1'}):bg.append(dict(scheme=s['name'],model=model,criterion=metric,accession=k,organism=meta[k]['organism'],clade=meta[k]['clade']))
write('recommended_pairs.csv',pr);write('recommended_offtargets.csv',bg)
(p/'recommended_sets.json').write_text(json.dumps(selected,indent=2));(p/'pruned_validation_sets.json').write_text(json.dumps(sets,indent=2));(out/'validation.json').write_text(json.dumps(dict(status='PASS',comparisons=checks,unique_pairs=len(pairs),target_records=1848,background_records=5600,new_reference_status='2 provisional homology-inferred loci; full original genomes scanned; 6 UNVERIFIED records excluded',selection='separate PCR; <=20 WC3 and GT2 record unions; coverage loss <=0.5 percentage points on both panels; Apodida own-region coverage maintained; exact coverage improved; no more pairs than published; within 1 percentage point exact of best feasible scheme choose fewer pairs',wet_lab_validated=False),indent=2))
