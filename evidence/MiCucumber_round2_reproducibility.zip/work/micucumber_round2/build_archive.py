from pathlib import Path
import json,zipfile,hashlib
root=Path(__file__).resolve().parents[2];out=root/'outputs/MiCucumber_round2';p=root/'work/micucumber_round2';q=p/'optimization'
repro='''from pathlib import Path
import subprocess,sys,tempfile,json,hashlib
root=Path(__file__).resolve().parent
p=root/'work/micucumber_round2/optimization'
manifest=json.loads((root/'SHA256SUMS.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Frozen file checksums PASS',len(manifest),flush=True)
subprocess.run(['c++','-O3','-std=c++17',str(p/'independent_scan.cpp'),'-o',str(p/'independent_scan')],check=True)
subprocess.run([sys.executable,str(p/'validate_targets.py')],check=True)
subprocess.run([str(p/'independent_scan'),str(p)],check=True)
for script in ['summarize_round2.py','physical_resolution.py']:
 subprocess.run([sys.executable,str(p/script)],check=True)
print('Revalidation complete. See outputs/MiCucumber_round2/validation.json',flush=True)
'''
files={}
for f in out.iterdir():
 if f.is_file() and f.suffix not in ['.zip'] and f.name!='SHA256SUMS.json':files[str(f.relative_to(root))]=f.read_bytes()
for f in q.iterdir():
 if f.is_file() and f.suffix in ['.py','.json','.tsv','.fasta'] and f.name!='target_barcodes.tsv':files[str(f.relative_to(root))]=f.read_bytes()
files[str((q/'independent_scan.cpp').relative_to(root))]=(root/'work/micucumber/independent_scan.cpp').read_bytes()
for f in (q/'same_locus').iterdir():
 if f.is_file() and not f.is_symlink() and f.suffix in ['.py','.json','.tsv','.npz'] and f.name!='rank_input.txt':files[str(f.relative_to(root))]=f.read_bytes()
for f in (q/'thermal').iterdir():
 if f.is_file():files[str(f.relative_to(root))]=f.read_bytes()
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.py','.json','.csv','.gb','.fasta'] and f.name!='expanded_aligned.fasta':files[str(f.relative_to(root))]=f.read_bytes()
files['run_revalidation.py']=repro.encode();files['requirements.txt']=b'biopython==1.87\nnumpy>=2.4\nscipy==1.18.1\nprimer3-py==2.3.1\nmatplotlib>=3.10\n'
files['README.txt']='''MiCucumber round 2 — frozen computational evidence / 冻结计算证据
Install Python 3.12 dependencies: python -m pip install -r requirements.txt
Re-run independent validation: python run_revalidation.py
Requires a C++17 compiler on PATH. This checks frozen hashes, scans original target/background sequences, compares Python/C++ results, and recomputes portfolio and physical-barcode tables.
Optimization: work/micucumber_round2/optimization/optimize_verified.py can re-run MILP on the verified candidate pool after installing SciPy. Global primer optimality is not claimed.
Discovery source, candidate masks and risk tables are included for inspection. Legacy setup scripts contain historical input-tree dependencies and are provenance records, not standalone fresh-download commands. The supported one-command entry point reproduces final validation, not NCBI retrieval or all discovery stages.
Separate PCRs only. No wet-lab validation. Copyright: see outputs/MiCucumber_round2/COPYRIGHT.md.
'''.encode()
# Runtime imports use standard installed packages; omit machine-specific optional search paths.
for name,data in list(files.items()):
 if name.endswith('.py'):
  s=data.decode();s=s.replace("",'')
  files[name]=s.encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()};files['SHA256SUMS.json']=json.dumps(manifest,indent=2).encode()
archive=out/'MiCucumber_round2_reproducibility.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('Archive',archive.stat().st_size,'bytes',len(files),'files')
(out/'SHA256SUMS.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in out.iterdir() if f.is_file() and f.name!='SHA256SUMS.json'},indent=2))
